#!/usr/bin/env python3
"""Quote of the Day - entry point.

    python main.py                       launch the GUI
    python main.py today                 CLI: show today's quote
    python main.py register NAME         create a password-protected account
    python main.py --user NAME stats     CLI as a specific user
    python main.py --help                list every CLI command

Accounts are optional. Until one is registered the app is single-user;
afterwards a login is required and every user's data is kept separate.
"""
import argparse
import os
import sys
from typing import List, Optional

from quote_app.bootstrap import build_auth_service, build_service
from quote_app.errors import QuoteAppError
from quote_app.presentation import auth_cli, cli


def main(argv: Optional[List[str]] = None,
         read_password: Optional[auth_cli.PasswordReader] = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    prelim = argparse.ArgumentParser(add_help=False)
    prelim.add_argument("--user")
    options, rest = prelim.parse_known_args(argv)
    try:
        auth = build_auth_service()
        if rest[:1] == ["register"]:
            return auth_cli.register(auth, rest[1:], read_password)
        if rest:
            return _run_cli(rest, options.user, auth, read_password)
        return _run_gui(options.user, auth, read_password)
    except QuoteAppError as exc:
        print("Error: {}".format(exc), file=sys.stderr)
        return 1


def _run_cli(rest, user, auth, read_password) -> int:
    username = None
    if user:
        username = auth_cli.login(auth, user, read_password)
    elif auth.accounts_exist():
        print("Error: accounts exist - add --user NAME", file=sys.stderr)
        return 1
    service = build_service(username)
    try:
        return cli.run(rest, service)
    except BrokenPipeError:
        # Output was piped to something like `head`; exit quietly.
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        return 0


def _run_gui(user, auth, read_password) -> int:
    try:
        from quote_app.presentation import gui
    except ImportError:
        print("Tkinter is not available on this system. "
              "Use the CLI instead, e.g. 'python main.py today'.",
              file=sys.stderr)
        return 1
    username = None
    if user:
        username = auth_cli.login(auth, user, read_password)
    elif auth.accounts_exist():
        username = gui.login_dialog(auth)
        if username is None:
            return 0
    return gui.launch(build_service(username), username)


if __name__ == "__main__":
    sys.exit(main())
