"""Backend-specific behaviour (corruption handling, file layout)."""
import json
import sqlite3
import unittest
from unittest import mock

from quote_app.data.repository import JsonRepository
from quote_app.data.sqlite_repository import SqliteRepository
from quote_app.errors import StorageError
from quote_app.models import ObservationKind, Quote, QuoteObservation
from tests.helpers import ServiceTestCase


def make(text="A quote", author="Ann"):
    return Quote.create(text, author, ["t"])


class JsonRepositoryTests(ServiceTestCase):
    def test_corrupt_file_is_quarantined(self):
        path = self.dir / "bad.json"
        path.write_text("{ this is not json", encoding="utf-8")
        repo = JsonRepository(path)
        self.assertEqual(repo.all_quotes(), [])
        self.assertEqual(len(list(self.dir.glob("bad.json.corrupt-*"))), 1)
        repo.add_quote(make())
        self.assertTrue(path.exists())

    def test_structurally_invalid_file_is_quarantined(self):
        path = self.dir / "bad.json"
        path.write_text(json.dumps({"quotes": [{"id": "x"}]}),
                        encoding="utf-8")
        JsonRepository(path)
        self.assertEqual(len(list(self.dir.glob("*.corrupt-*"))), 1)

    def test_orphans_are_dropped_on_load(self):
        path = self.dir / "orph.json"
        quote = make()
        obs = QuoteObservation.create("ghost", ObservationKind.VIEW)
        path.write_text(json.dumps({
            "quotes": [quote.to_dict()], "observations": [obs.to_dict()],
            "daily": {"2026-01-01": "ghost"}}), encoding="utf-8")
        repo = JsonRepository(path)
        self.assertEqual(repo.observations(), [])
        self.assertIsNone(repo.get_daily("2026-01-01"))

    def test_no_temp_files_left_behind(self):
        self.repo.add_quote(make())
        self.assertEqual(list(self.dir.glob(".tmp-*")), [])


class SqliteRepositoryTests(ServiceTestCase):
    def make_repo(self, directory):
        return SqliteRepository(directory / "quotes.db")

    def test_garbage_file_is_quarantined(self):
        path = self.dir / "junk.db"
        path.write_bytes(b"this is definitely not a sqlite database" * 50)
        repo = SqliteRepository(path)
        self.addCleanup(repo.close)
        self.assertEqual(repo.all_quotes(), [])
        self.assertEqual(len(list(self.dir.glob("junk.db.corrupt-*"))), 1)
        repo.add_quote(make())  # fresh database is fully usable
        self.assertEqual(len(repo.all_quotes()), 1)

    def test_schema_has_foreign_keys_and_checks(self):
        quote, _ = self.repo.add_quote(make())
        raw = sqlite3.connect(str(self.dir / "quotes.db"))
        self.addCleanup(raw.close)
        raw.execute("PRAGMA foreign_keys = ON")
        with self.assertRaises(sqlite3.IntegrityError):  # bad parent
            raw.execute("INSERT INTO observations VALUES "
                        "('o','ghost','2026-01-01T00:00:00','view',NULL,'')")
        with self.assertRaises(sqlite3.IntegrityError):  # rating CHECK
            raw.execute("INSERT INTO observations VALUES "
                        "('o2',?, '2026-01-01T00:00:00','rating',9,'')",
                        (quote.id,))

    def test_operations_after_close_raise_storage_error(self):
        self.repo.close()
        with self.assertRaises(StorageError):
            self.repo.all_quotes()
        self.repo = self.make_repo(self.dir)  # let cleanup close it

    def test_sqlite_errors_become_storage_errors(self):
        with mock.patch.object(self.repo, "_conn") as conn:
            conn.__enter__ = mock.Mock(
                side_effect=sqlite3.OperationalError("disk full"))
            conn.__exit__ = mock.Mock(return_value=False)
            with self.assertRaises(StorageError):
                self.repo.all_quotes()

    def test_unopenable_path_is_storage_error(self):
        blocker = self.dir / "file"
        blocker.write_text("x")
        with self.assertRaises((StorageError, OSError)):
            SqliteRepository(blocker / "sub" / "q.db")

    def test_bad_tags_column_is_data_error(self):
        from quote_app.errors import DataError
        quote, _ = self.repo.add_quote(make())
        self.repo._conn.execute("UPDATE quotes SET tags='not json'")
        with self.assertRaises(DataError):
            self.repo.get_quote(quote.id)


if __name__ == "__main__":
    unittest.main()
