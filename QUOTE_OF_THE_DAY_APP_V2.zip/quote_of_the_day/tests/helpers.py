"""Shared test fixtures: temp storage, fake HTTP, fixed clock."""
import json
import random
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from quote_app.business.services import QuoteService
from quote_app.data.api_client import QuoteApiClient
from quote_app.data.repository import JsonRepository
from quote_app.errors import ApiError


class FakeClock:
    def __init__(self, start=datetime(2026, 11, 26, 9, 0, 0)):
        self.now = start

    def __call__(self):
        return self.now

    def advance(self, **kwargs):
        self.now += timedelta(**kwargs)


class FakeHttp:
    """Returns canned responses per URL; exceptions are raised."""

    def __init__(self, responses=None):
        self.responses = responses or {}
        self.calls = []

    def __call__(self, url, timeout):
        self.calls.append(url)
        result = self.responses.get(url)
        if result is None:
            raise ApiError("no response configured for " + url)
        if isinstance(result, Exception):
            raise result
        if isinstance(result, (dict, list)):
            return json.dumps(result).encode("utf-8")
        return result if isinstance(result, bytes) else result.encode()


ZEN_TODAY = "https://zenquotes.io/api/today"
ZEN_RANDOM = "https://zenquotes.io/api/random"
DUMMY = "https://dummyjson.com/quotes/random"


class ServiceTestCase(unittest.TestCase):
    """Builds a service on a temp directory with fake collaborators."""

    def make_repo(self, directory):
        """Storage backend under test; subclasses override this."""
        return JsonRepository(directory / "quotes.json")

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = Path(self._tmp.name)
        self.clock = FakeClock()
        self.http = FakeHttp()
        self.repo = self.make_repo(self.dir)
        self.addCleanup(self.repo.close)
        self.client = QuoteApiClient(self.http, retries=0,
                                     sleep=lambda _s: None)
        self.service = QuoteService(self.repo, self.client, self.clock,
                                    random.Random(1))
