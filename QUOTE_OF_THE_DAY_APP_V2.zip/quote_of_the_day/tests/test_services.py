import urllib.error

from quote_app.errors import NotFoundError, ValidationError
from quote_app.models import (ObservationKind, QuoteObservation,
                              QuoteSource)
from tests.helpers import DUMMY, ZEN_RANDOM, ZEN_TODAY, ServiceTestCase


class QuoteOfTheDayTests(ServiceTestCase):
    def test_fetches_from_api_then_serves_from_cache(self):
        self.http.responses[ZEN_TODAY] = [
            {"q": "Carpe diem now", "a": "Horace"}]
        first = self.service.get_quote_of_the_day()
        second = self.service.get_quote_of_the_day()
        self.assertEqual(first.origin, "api")
        self.assertEqual(second.origin, "cached")
        self.assertEqual(first.quote.id, second.quote.id)
        self.assertEqual(self.http.calls, [ZEN_TODAY])  # one network call
        self.assertEqual(first.quote.source, QuoteSource.API)

    def test_new_day_fetches_again(self):
        self.http.responses[ZEN_TODAY] = [{"q": "Day one quote", "a": "A"}]
        self.service.get_quote_of_the_day()
        self.clock.advance(days=1)
        self.http.responses[ZEN_TODAY] = [{"q": "Day two quote", "a": "B"}]
        result = self.service.get_quote_of_the_day()
        self.assertEqual(result.quote.text, "Day two quote")
        self.assertEqual(result.origin, "api")

    def test_offline_fallback_is_deterministic_per_day(self):
        first = self.service.get_quote_of_the_day()
        self.assertEqual(first.origin, "offline")
        self.assertEqual(first.quote.source, QuoteSource.OFFLINE)
        # Bypass the cache on the same day: the offline pick must not change.
        again = self.service.get_quote_of_the_day(force_refresh=True)
        self.assertEqual(first.quote.id, again.quote.id)

    def test_force_refresh_retries_api(self):
        offline = self.service.get_quote_of_the_day()
        self.assertEqual(offline.origin, "offline")
        self.http.responses[ZEN_TODAY] = [{"q": "Now online!", "a": "Net"}]
        refreshed = self.service.get_quote_of_the_day(force_refresh=True)
        self.assertEqual(refreshed.origin, "api")
        self.assertEqual(self.repo.get_daily("2026-11-26"),
                         refreshed.quote.id)

    def test_invalid_api_payload_falls_back(self):
        self.http.responses[ZEN_TODAY] = [{"q": "x", "a": "y"}]  # too short
        self.http.responses[DUMMY] = {"quote": "ok", "author": "z"}
        self.assertEqual(self.service.get_quote_of_the_day().origin,
                         "offline")

    def test_each_display_records_a_view(self):
        result = self.service.get_quote_of_the_day()
        self.service.get_quote_of_the_day()
        self.assertEqual(self.service.get_quote(result.quote.id).views, 2)

    def test_random_online_and_offline(self):
        self.http.responses[ZEN_RANDOM] = [{"q": "Random one", "a": "R"}]
        self.assertEqual(self.service.fetch_random_quote().origin, "api")
        self.http.responses[ZEN_RANDOM] = urllib.error.URLError("x")
        self.assertEqual(self.service.fetch_random_quote().origin, "offline")


class LibraryTests(ServiceTestCase):
    def setUp(self):
        super().setUp()
        self.a = self.service.add_manual_quote(
            "Courage is grace under pressure", "Hemingway", "courage, grit")
        self.clock.advance(minutes=1)
        self.b = self.service.add_manual_quote(
            "Make it work, make it right", "Kent Beck", "programming")
        self.clock.advance(minutes=1)
        self.c = self.service.add_manual_quote(
            "Programs must be readable", "Abelson", "programming, clarity")

    def texts(self, **kwargs):
        return [v.quote.id for v in self.service.search(**kwargs)]

    def test_add_validates_and_rejects_duplicates(self):
        with self.assertRaises(ValidationError):
            self.service.add_manual_quote("hi", "x")
        with self.assertRaises(ValidationError):
            self.service.add_manual_quote(
                "  courage is GRACE under pressure ", "hemingway")

    def test_search_text_author_tag(self):
        self.assertEqual(self.texts(query="grace PRESSURE"), [self.a.id])
        self.assertEqual(self.texts(query="beck"), [self.b.id])
        self.assertEqual(self.texts(query="clarity"), [self.c.id])
        self.assertEqual(self.texts(author="abel"), [self.c.id])
        self.assertEqual(set(self.texts(tag="programming")),
                         {self.b.id, self.c.id})
        self.assertEqual(self.texts(query="nomatch"), [])

    def test_search_all_words_must_match(self):
        self.assertEqual(self.texts(query="make programming"), [self.b.id])

    def test_sorting(self):
        self.assertEqual(self.texts(sort="newest"),
                         [self.c.id, self.b.id, self.a.id])
        self.assertEqual(self.texts(sort="oldest"),
                         [self.a.id, self.b.id, self.c.id])
        self.assertEqual(self.texts(sort="author"),
                         [self.c.id, self.a.id, self.b.id])

    def test_invalid_sort_and_query(self):
        with self.assertRaises(ValidationError):
            self.service.search(sort="chaos")
        with self.assertRaises(ValidationError):
            self.service.search(query="x" * 500)

    def test_favorites_filter_and_toggle(self):
        self.assertTrue(self.service.toggle_favorite(self.b.id))
        self.assertEqual(self.texts(favorites_only=True), [self.b.id])
        self.assertFalse(self.service.toggle_favorite(self.b.id))
        self.assertEqual(self.texts(favorites_only=True), [])
        kinds = [o.kind for o in self.service.history(self.b.id)]
        self.assertEqual(kinds, [ObservationKind.UNFAVORITE,
                                 ObservationKind.FAVORITE])

    def test_ratings_latest_wins_and_filter(self):
        self.service.rate_quote(self.a.id, 2)
        self.clock.advance(seconds=5)
        self.service.rate_quote(self.a.id, 5)
        self.service.rate_quote(self.b.id, 3)
        self.assertEqual(self.service.get_quote(self.a.id).rating, 5)
        self.assertEqual(self.texts(min_rating=4), [self.a.id])
        self.assertEqual(self.texts(sort="rating"),
                         [self.a.id, self.b.id, self.c.id])
        with self.assertRaises(ValidationError):
            self.service.rate_quote(self.a.id, 9)

    def test_views_sort(self):
        for _ in range(2):
            self.repo.add_observation(
                QuoteObservation.create(self.c.id, ObservationKind.VIEW))
        self.assertEqual(self.texts(sort="views")[0], self.c.id)

    def test_notes(self):
        self.service.add_note(self.a.id, "  great one ")
        history = self.service.history(self.a.id)
        self.assertEqual(history[0].note, "great one")
        with self.assertRaises(ValidationError):
            self.service.add_note(self.a.id, "")

    def test_unknown_ids(self):
        for call in (lambda: self.service.get_quote("zzz"),
                     lambda: self.service.toggle_favorite("zzz"),
                     lambda: self.service.rate_quote("zzz", 3),
                     lambda: self.service.add_note("zzz", "hi"),
                     lambda: self.service.history("zzz"),
                     lambda: self.service.delete_quote("zzz")):
            with self.assertRaises(NotFoundError):
                call()

    def test_delete(self):
        self.service.rate_quote(self.a.id, 4)
        self.service.delete_quote(self.a.id)
        self.assertEqual(len(self.service.search()), 2)
        self.assertEqual(self.repo.observations(self.a.id), [])


class CsvTests(ServiceTestCase):
    def test_export_import_round_trip(self):
        q = self.service.add_manual_quote("Round trip works", "Ann",
                                          "one, two")
        self.service.toggle_favorite(q.id)
        out = self.dir / "out.csv"
        self.assertEqual(self.service.export_quotes_csv(out), 1)
        self.assertEqual(self.service.export_observations_csv(
            self.dir / "obs.csv"), 1)

        self.service.delete_quote(q.id)
        result = self.service.import_quotes_csv(out)
        self.assertEqual((result.added, result.skipped), (1, 0))
        restored = self.service.get_quote(q.id).quote
        self.assertEqual(restored.tags, ["one", "two"])
        self.assertTrue(restored.is_favorite)
        self.assertEqual(restored.source, QuoteSource.IMPORT)

    def test_import_skips_bad_rows_and_duplicates(self):
        self.service.add_manual_quote("Already here", "Ann")
        path = self.dir / "in.csv"
        path.write_text(
            "text,author,tags\n"
            "Already here,Ann,\n"
            "no,Bob,\n"
            "Fresh quote,Cy,<bad>\n"
            "Another fine one,Di,ok\n", encoding="utf-8")
        result = self.service.import_quotes_csv(path)
        self.assertEqual(result.added, 1)
        self.assertEqual(result.skipped, 3)
        self.assertEqual(len(result.errors), 2)

    def test_formula_injection_neutralised_and_restored(self):
        self.service.add_manual_quote("=HYPERLINK(1) evil", "+cmd")
        out = self.dir / "e.csv"
        self.service.export_quotes_csv(out)
        raw = out.read_text(encoding="utf-8")
        self.assertIn("'=HYPERLINK", raw)
        self.assertIn("'+cmd", raw)
        self.service.import_quotes_csv(out)  # duplicates, but must not crash

    def test_missing_file_is_storage_error(self):
        from quote_app.errors import StorageError
        with self.assertRaises(StorageError):
            self.service.import_quotes_csv(self.dir / "nope.csv")
