"""Behaviour every storage backend must satisfy."""
import unittest

from quote_app.data.sqlite_repository import SqliteRepository
from quote_app.errors import NotFoundError
from quote_app.models import ObservationKind, Quote, QuoteObservation
from tests.helpers import ServiceTestCase


class RepositoryContract:
    """Mixin: concrete classes provide ``make_repo`` via ServiceTestCase."""

    def make(self, text="A quote", author="Ann"):
        return Quote.create(text, author, ["t"])

    def reopen(self):
        self.repo.close()
        self.repo = self.make_repo(self.dir)
        self.addCleanup(self.repo.close)
        return self.repo

    def test_add_and_dedupe(self):
        stored, created = self.repo.add_quote(self.make())
        again, created_again = self.repo.add_quote(self.make())
        self.assertTrue(created)
        self.assertFalse(created_again)
        self.assertEqual(stored.id, again.id)
        self.assertEqual(len(self.repo.all_quotes()), 1)

    def test_persists_across_instances(self):
        quote, _ = self.repo.add_quote(self.make())
        self.repo.add_observation(
            QuoteObservation.create(quote.id, ObservationKind.VIEW))
        self.repo.set_daily("2026-11-26", quote.id)
        reopened = self.reopen()
        self.assertEqual(reopened.get_quote(quote.id), quote)
        self.assertEqual(len(reopened.observations(quote.id)), 1)
        self.assertEqual(reopened.get_daily("2026-11-26"), quote.id)

    def test_get_missing_returns_none(self):
        self.assertIsNone(self.repo.get_quote("nope"))
        self.assertIsNone(self.repo.get_daily("2026-01-01"))

    def test_returned_objects_are_copies(self):
        quote, _ = self.repo.add_quote(self.make())
        quote.tags.append("mutated")
        quote.author = "Hacker"
        self.assertEqual(self.repo.get_quote(quote.id).tags, ["t"])
        self.assertEqual(self.repo.get_quote(quote.id).author, "Ann")

    def test_update(self):
        quote, _ = self.repo.add_quote(self.make())
        quote.is_favorite = True
        quote.tags = ["x", "y"]
        self.repo.update_quote(quote)
        saved = self.repo.get_quote(quote.id)
        self.assertTrue(saved.is_favorite)
        self.assertEqual(saved.tags, ["x", "y"])

    def test_update_missing_raises(self):
        with self.assertRaises(NotFoundError):
            self.repo.update_quote(self.make())

    def test_observation_requires_parent(self):
        with self.assertRaises(NotFoundError):
            self.repo.add_observation(
                QuoteObservation.create("nope", ObservationKind.VIEW))

    def test_set_daily_requires_quote(self):
        with self.assertRaises(NotFoundError):
            self.repo.set_daily("2026-11-26", "nope")

    def test_observations_keep_insertion_order_and_filter(self):
        a, _ = self.repo.add_quote(self.make("First quote"))
        b, _ = self.repo.add_quote(self.make("Second quote"))
        for quote_id, rating in ((a.id, 1), (b.id, 2), (a.id, 3)):
            self.repo.add_observation(QuoteObservation.create(
                quote_id, ObservationKind.RATING, rating=rating))
        self.assertEqual([o.rating for o in self.repo.observations()],
                         [1, 2, 3])
        self.assertEqual([o.rating for o in self.repo.observations(a.id)],
                         [1, 3])

    def test_quotes_keep_insertion_order(self):
        for text in ("Third one", "First one", "Second one"):
            self.repo.add_quote(self.make(text))
        self.assertEqual([q.text for q in self.repo.all_quotes()],
                         ["Third one", "First one", "Second one"])

    def test_daily_can_be_replaced(self):
        a, _ = self.repo.add_quote(self.make("Quote a"))
        b, _ = self.repo.add_quote(self.make("Quote b"))
        self.repo.set_daily("2026-11-26", a.id)
        self.repo.set_daily("2026-11-26", b.id)
        self.assertEqual(self.repo.get_daily("2026-11-26"), b.id)

    def test_delete_cascades(self):
        quote, _ = self.repo.add_quote(self.make())
        self.repo.add_observation(
            QuoteObservation.create(quote.id, ObservationKind.VIEW))
        self.repo.set_daily("2026-11-26", quote.id)
        self.assertTrue(self.repo.delete_quote(quote.id))
        self.assertEqual(self.repo.observations(), [])
        self.assertIsNone(self.repo.get_daily("2026-11-26"))
        self.assertFalse(self.repo.delete_quote(quote.id))

    def test_unicode_and_quotes_round_trip(self):
        text = ("Cafe \u2615 \"quoted\" \u2014 "
                "\u0c24\u0c46\u0c32\u0c41\u0c17\u0c41 'single'")
        quote, _ = self.repo.add_quote(Quote.create(text, "Z\u00e9"))
        self.assertEqual(self.reopen().get_quote(quote.id).text, text)

    def test_sql_injection_text_is_stored_literally(self):
        evil = "x'); DROP TABLE quotes;--"
        quote, _ = self.repo.add_quote(Quote.create(evil, evil))
        self.assertEqual(self.repo.get_quote(quote.id).text, evil)
        self.assertEqual(len(self.repo.all_quotes()), 1)

    def test_concurrent_writers_do_not_lose_data(self):
        import threading
        quote, _ = self.repo.add_quote(self.make())
        errors = []

        def worker():
            try:
                for _ in range(25):
                    self.repo.add_observation(QuoteObservation.create(
                        quote.id, ObservationKind.VIEW))
            except Exception as exc:  # pragma: no cover - failure path
                errors.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual(errors, [])
        self.assertEqual(len(self.repo.observations(quote.id)), 100)

    def test_close_is_idempotent(self):
        self.repo.close()
        self.repo.close()
        self.repo = self.make_repo(self.dir)


class JsonContractTests(RepositoryContract, ServiceTestCase):
    pass


class SqliteContractTests(RepositoryContract, ServiceTestCase):
    def make_repo(self, directory):
        return SqliteRepository(directory / "quotes.db")


if __name__ == "__main__":
    unittest.main()
