import unittest

from quote_app import config
from quote_app.business import validation as v
from quote_app.errors import ValidationError


class ValidationTests(unittest.TestCase):
    def test_text_is_cleaned(self):
        self.assertEqual(v.validate_quote_text("  Hi \n  there\x00 "),
                         "Hi there")

    def test_text_too_short_or_long(self):
        with self.assertRaises(ValidationError):
            v.validate_quote_text("ab")
        with self.assertRaises(ValidationError):
            v.validate_quote_text("x" * (config.MAX_QUOTE_LENGTH + 1))

    def test_text_must_be_string(self):
        with self.assertRaises(ValidationError):
            v.validate_quote_text(None)
        with self.assertRaises(ValidationError):
            v.validate_quote_text(123)

    def test_author_defaults_to_unknown(self):
        self.assertEqual(v.validate_author(""), "Unknown")
        self.assertEqual(v.validate_author(None), "Unknown")
        self.assertEqual(v.validate_author("  Ann  Lee "), "Ann Lee")

    def test_author_too_long(self):
        with self.assertRaises(ValidationError):
            v.validate_author("a" * (config.MAX_AUTHOR_LENGTH + 1))

    def test_tags_parse_dedupe_lowercase(self):
        self.assertEqual(v.parse_tags("Life, WORK;life , "),
                         ["life", "work"])
        self.assertEqual(v.parse_tags(["A", "b"]), ["a", "b"])
        self.assertEqual(v.parse_tags(None), [])

    def test_tags_reject_bad_characters(self):
        with self.assertRaises(ValidationError):
            v.parse_tags("<script>")

    def test_tags_limits(self):
        with self.assertRaises(ValidationError):
            v.parse_tags("t" * (config.MAX_TAG_LENGTH + 1))
        with self.assertRaises(ValidationError):
            v.parse_tags(",".join("tag%d" % i
                                  for i in range(config.MAX_TAGS + 1)))

    def test_rating(self):
        self.assertEqual(v.validate_rating("4"), 4)
        for bad in (0, 6, -1, "x", None, True, 2.5):
            with self.assertRaises(ValidationError):
                v.validate_rating(bad)

    def test_note(self):
        self.assertEqual(v.validate_note(" nice "), "nice")
        with self.assertRaises(ValidationError):
            v.validate_note("   ")
        with self.assertRaises(ValidationError):
            v.validate_note("n" * (config.MAX_NOTE_LENGTH + 1))

    def test_query(self):
        self.assertEqual(v.validate_query(None), "")
        with self.assertRaises(ValidationError):
            v.validate_query("q" * (config.MAX_QUERY_LENGTH + 1))


if __name__ == "__main__":
    unittest.main()
