"""Re-run the whole service suite on the SQLite backend."""
import unittest

import tests.test_services as base
from quote_app.data.sqlite_repository import SqliteRepository


class SqliteBackend:
    def make_repo(self, directory):
        return SqliteRepository(directory / "quotes.db")


class SqliteDailyTests(SqliteBackend, base.QuoteOfTheDayTests):
    pass


class SqliteLibraryTests(SqliteBackend, base.LibraryTests):
    pass


class SqliteCsvTests(SqliteBackend, base.CsvTests):
    pass


if __name__ == "__main__":
    unittest.main()
