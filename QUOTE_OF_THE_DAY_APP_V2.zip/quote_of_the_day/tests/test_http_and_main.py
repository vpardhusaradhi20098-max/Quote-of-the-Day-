import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

import main
from quote_app import config
from quote_app.data import api_client
from quote_app.errors import ApiError


class FakeResponse:
    def __init__(self, body):
        self._body = body

    def read(self, limit=-1):
        return self._body[:limit] if limit >= 0 else self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class DefaultHttpGetTests(unittest.TestCase):
    def test_rejects_plain_http(self):
        with self.assertRaises(ApiError):
            api_client.default_http_get("http://example.com", 1)

    def test_returns_body(self):
        with mock.patch("urllib.request.urlopen",
                        return_value=FakeResponse(b"[1]")) as opened:
            self.assertEqual(
                api_client.default_http_get("https://x.test", 3), b"[1]")
        self.assertEqual(opened.call_args.kwargs["timeout"], 3)

    def test_rejects_oversized_response(self):
        big = b"x" * (config.MAX_RESPONSE_BYTES + 10)
        with mock.patch("urllib.request.urlopen",
                        return_value=FakeResponse(big)):
            with self.assertRaises(ApiError):
                api_client.default_http_get("https://x.test", 1)


class MainTests(unittest.TestCase):
    def test_cli_end_to_end_offline(self):
        """Full stack with the network blocked: must fall back offline."""
        with tempfile.TemporaryDirectory() as tmp, \
                mock.patch.dict(os.environ, {"QOTD_DATA_DIR": tmp}), \
                mock.patch("urllib.request.urlopen",
                           side_effect=OSError("network blocked")), \
                mock.patch("time.sleep"):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                code = main.main(["today"])
            self.assertEqual(code, 0)
            self.assertIn("(source: offline)", out.getvalue())
            self.assertTrue(os.path.exists(os.path.join(tmp, "quotes.db")))


class MainAuthTests(unittest.TestCase):
    """Accounts are opt-in; once created, login is required."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        patcher = mock.patch.dict(os.environ, {
            "QOTD_DATA_DIR": self._tmp.name, "QOTD_PASSWORD": "s3cretpass"})
        patcher.start()
        self.addCleanup(patcher.stop)
        for target in ("time.sleep",):
            p = mock.patch(target)
            p.start()
            self.addCleanup(p.stop)
        p = mock.patch("urllib.request.urlopen",
                       side_effect=OSError("network blocked"))
        p.start()
        self.addCleanup(p.stop)
        p = mock.patch("quote_app.config.PBKDF2_ITERATIONS", 10)
        p.start()
        self.addCleanup(p.stop)

    def run_main(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), \
                contextlib.redirect_stderr(err):
            code = main.main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def test_anonymous_mode_until_first_account(self):
        self.assertEqual(self.run_main("today")[0], 0)

    def test_register_then_login_required(self):
        self.assertEqual(self.run_main("register", "alice")[0], 0)
        code, _, err = self.run_main("today")
        self.assertEqual(code, 1)
        self.assertIn("--user", err)
        code, out, _ = self.run_main("--user", "alice", "today")
        self.assertEqual(code, 0)
        self.assertIn("(source: offline)", out)

    def test_wrong_password_is_rejected(self):
        self.run_main("register", "alice")
        with mock.patch.dict(os.environ, {"QOTD_PASSWORD": "wrongpass1"}):
            code, _, err = self.run_main("--user", "alice", "today")
        self.assertEqual(code, 1)
        self.assertIn("Invalid username or password", err)

    def test_users_have_isolated_data(self):
        self.run_main("register", "alice")
        self.run_main("register", "bobby")
        self.run_main("--user", "alice", "add", "Alice private quote")
        _, out, _ = self.run_main("--user", "alice", "list")
        self.assertIn("Alice private quote", out)
        _, out, _ = self.run_main("--user", "bobby", "list")
        self.assertIn("No quotes found.", out)

    def test_register_rejects_weak_password_and_duplicates(self):
        with mock.patch.dict(os.environ, {"QOTD_PASSWORD": "weak"}):
            self.assertEqual(self.run_main("register", "alice")[0], 1)
        self.assertEqual(self.run_main("register", "alice")[0], 0)
        self.assertEqual(self.run_main("register", "alice")[0], 1)

    def test_register_usage(self):
        self.assertEqual(self.run_main("register")[0], 2)

    def test_json_backend_selectable(self):
        with mock.patch.dict(os.environ, {"QOTD_STORAGE": "json"}):
            self.assertEqual(self.run_main("today")[0], 0)
        self.assertTrue(os.path.exists(
            os.path.join(self._tmp.name, "quotes.json")))

    def test_invalid_backend_is_reported(self):
        with mock.patch.dict(os.environ, {"QOTD_STORAGE": "mongo"}):
            code, _, err = self.run_main("today")
        self.assertEqual(code, 1)
        self.assertIn("QOTD_STORAGE", err)


if __name__ == "__main__":
    unittest.main()
