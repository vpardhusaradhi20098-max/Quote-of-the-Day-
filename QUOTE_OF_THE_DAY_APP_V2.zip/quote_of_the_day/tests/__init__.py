"""Test package. Silences application logging to keep test output clean."""
import logging

logging.disable(logging.CRITICAL)
