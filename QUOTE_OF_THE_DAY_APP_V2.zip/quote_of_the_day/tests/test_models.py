import unittest
from datetime import datetime

from quote_app.errors import DataError
from quote_app.models import (DetailObservation, ObservationKind,
                              PrimaryRecord, Quote, QuoteObservation,
                              make_quote_id)


class QuoteModelTests(unittest.TestCase):
    def test_id_is_deterministic_and_normalised(self):
        a = make_quote_id("Hello  World", "Ann")
        b = make_quote_id("hello world", "  ann ")
        self.assertEqual(a, b)
        self.assertNotEqual(a, make_quote_id("Hello World", "Bob"))

    def test_quote_is_a_primary_record(self):
        quote = Quote.create("Be kind.", "Ann", ["kindness"])
        self.assertIsInstance(quote, PrimaryRecord)
        self.assertEqual(quote.tags, ["kindness"])

    def test_quote_round_trip(self):
        quote = Quote.create("Be kind.", "Ann", ["a", "b"],
                             moment=datetime(2026, 1, 2, 3, 4, 5))
        self.assertEqual(Quote.from_dict(quote.to_dict()), quote)

    def test_quote_from_dict_missing_field(self):
        with self.assertRaises(DataError):
            Quote.from_dict({"id": "x"})

    def test_quote_from_dict_bad_tags(self):
        with self.assertRaises(DataError):
            Quote.from_dict({"id": "x", "created_at": "t", "text": "t",
                             "author": "a", "tags": "oops"})

    def test_observation_is_a_detail_observation(self):
        obs = QuoteObservation.create("q1", ObservationKind.RATING, rating=4)
        self.assertIsInstance(obs, DetailObservation)
        self.assertEqual(obs.parent_id, "q1")

    def test_observation_round_trip(self):
        obs = QuoteObservation.create("q1", ObservationKind.NOTE, note="hi")
        self.assertEqual(QuoteObservation.from_dict(obs.to_dict()), obs)

    def test_observation_rejects_unknown_kind(self):
        with self.assertRaises(DataError):
            QuoteObservation.create("q1", "explode")
        with self.assertRaises(DataError):
            QuoteObservation.from_dict({
                "obs_id": "1", "parent_id": "q", "kind": "explode",
                "timestamp": "2026-01-01T00:00:00"})

    def test_observation_rejects_bad_timestamp(self):
        with self.assertRaises(DataError):
            QuoteObservation.from_dict({
                "obs_id": "1", "parent_id": "q", "kind": "view",
                "timestamp": "yesterday"})


if __name__ == "__main__":
    unittest.main()
