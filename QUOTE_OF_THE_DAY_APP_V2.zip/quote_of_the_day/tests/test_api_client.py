import unittest
import urllib.error

from quote_app.data.api_client import (QuoteApiClient, parse_dummyjson,
                                       parse_zenquotes)
from quote_app.errors import ApiError
from tests.helpers import DUMMY, ZEN_RANDOM, ZEN_TODAY, FakeHttp


def client(http, retries=0, sleeps=None):
    return QuoteApiClient(http, retries=retries, backoff=1,
                          sleep=(sleeps.append if sleeps is not None
                                 else (lambda _s: None)))


class ParserTests(unittest.TestCase):
    def test_zenquotes_ok(self):
        raw = parse_zenquotes([{"q": "Text", "a": "Auth"}])
        self.assertEqual((raw.text, raw.author, raw.provider),
                         ("Text", "Auth", "zenquotes"))

    def test_zenquotes_rejects_bad_shapes(self):
        for bad in ([], {}, [1], [{"q": "x"}], [{"q": 1, "a": 2}], "s"):
            with self.assertRaises(ApiError):
                parse_zenquotes(bad)

    def test_zenquotes_rate_limit_placeholder(self):
        with self.assertRaises(ApiError):
            parse_zenquotes([{"q": "Too many requests", "a": "zenquotes.io"}])

    def test_dummyjson(self):
        raw = parse_dummyjson({"quote": "T", "author": "A"})
        self.assertEqual(raw.provider, "dummyjson")
        for bad in ([], {"quote": 1}, {"author": "x"}):
            with self.assertRaises(ApiError):
                parse_dummyjson(bad)


class ClientTests(unittest.TestCase):
    def test_today_from_first_provider(self):
        http = FakeHttp({ZEN_TODAY: [{"q": "Hello there", "a": "Ann"}]})
        raw = client(http).fetch_today()
        self.assertEqual(raw.text, "Hello there")
        self.assertEqual(http.calls, [ZEN_TODAY])

    def test_random_failover_to_second_provider(self):
        http = FakeHttp({ZEN_RANDOM: urllib.error.URLError("down"),
                         DUMMY: {"quote": "Backup", "author": "Bob"}})
        raw = client(http).fetch_random()
        self.assertEqual(raw.provider, "dummyjson")

    def test_bad_json_is_handled(self):
        http = FakeHttp({ZEN_TODAY: b"<html>nope", DUMMY: b"\xff\xfe"})
        with self.assertRaises(ApiError):
            client(http).fetch_today()

    def test_retry_with_backoff(self):
        sleeps = []
        http = FakeHttp({ZEN_TODAY: TimeoutError("slow"),
                         DUMMY: TimeoutError("slow")})
        with self.assertRaises(ApiError):
            client(http, retries=2, sleeps=sleeps).fetch_today()
        self.assertEqual(sleeps, [1, 2, 1, 2])
        self.assertEqual(len(http.calls), 6)

    def test_all_fail_message(self):
        with self.assertRaises(ApiError) as ctx:
            client(FakeHttp()).fetch_random()
        self.assertIn("All quote providers failed", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
