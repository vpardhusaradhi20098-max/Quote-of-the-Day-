import unittest
from datetime import date, datetime

from quote_app.business.analytics import compute_analytics, compute_streaks
from quote_app.models import ObservationKind, Quote, QuoteObservation


def obs(qid, kind, when, rating=None):
    return QuoteObservation.create(qid, kind, rating=rating, moment=when)


class StreakTests(unittest.TestCase):
    D = date

    def test_empty(self):
        self.assertEqual(compute_streaks([], self.D(2026, 1, 1)), (0, 0))

    def test_current_and_longest(self):
        days = [self.D(2026, 1, d) for d in (1, 2, 3, 5, 6)]
        self.assertEqual(compute_streaks(days, self.D(2026, 1, 6)), (2, 3))

    def test_streak_alive_if_yesterday(self):
        days = [self.D(2026, 1, 4), self.D(2026, 1, 5)]
        self.assertEqual(compute_streaks(days, self.D(2026, 1, 6)), (2, 2))

    def test_streak_broken(self):
        days = [self.D(2026, 1, 1), self.D(2026, 1, 2)]
        self.assertEqual(compute_streaks(days, self.D(2026, 1, 10)), (0, 2))

    def test_duplicates_ignored(self):
        days = [self.D(2026, 1, 1)] * 3
        self.assertEqual(compute_streaks(days, self.D(2026, 1, 1)), (1, 1))


class ReportTests(unittest.TestCase):
    def test_empty_report(self):
        report = compute_analytics([], [], today=date(2026, 1, 1))
        self.assertEqual(report.total_quotes, 0)
        self.assertIsNone(report.average_rating)
        self.assertEqual(report.top_authors, [])

    def test_full_report(self):
        a = Quote.create("one two three", "Ann", ["x", "y"])
        b = Quote.create("four five", "Ann", ["x"])
        c = Quote.create("six", "Bob", [])
        b.is_favorite = True
        t1, t2 = datetime(2026, 1, 1, 9), datetime(2026, 1, 2, 9)
        observations = [
            obs(a.id, ObservationKind.VIEW, t1),
            obs(a.id, ObservationKind.VIEW, t2),
            obs(b.id, ObservationKind.VIEW, t2),
            obs(a.id, ObservationKind.RATING, t1, 2),
            obs(a.id, ObservationKind.RATING, t2, 4),
            obs(b.id, ObservationKind.RATING, t1, 5),
            obs("deleted", ObservationKind.RATING, t1, 1),
        ]
        r = compute_analytics([a, b, c], observations, date(2026, 1, 2))
        self.assertEqual(r.total_quotes, 3)
        self.assertEqual(r.favorites, 1)
        self.assertEqual(r.unique_authors, 2)
        self.assertEqual(r.average_words, 2.0)
        self.assertEqual(r.total_views, 3)
        self.assertEqual(r.rated_quotes, 2)
        self.assertEqual(r.average_rating, 4.5)
        self.assertEqual(r.rating_distribution[4], 1)
        self.assertEqual(r.rating_distribution[5], 1)
        self.assertEqual(r.top_authors[0], ("Ann", 2))
        self.assertEqual(r.top_tags[0], ("x", 2))
        self.assertEqual(r.most_viewed[0], ("one two three", 2))
        self.assertEqual(r.views_by_day, {"2026-01-01": 1, "2026-01-02": 2})
        self.assertEqual((r.current_streak, r.longest_streak), (2, 2))


if __name__ == "__main__":
    unittest.main()
