import json
import unittest

from quote_app.business.auth import (GENERIC_FAILURE, AuthService,
                                     validate_password, validate_username)
from quote_app.data.user_store import UserStore
from quote_app.errors import AuthError, StorageError, ValidationError
from tests.helpers import FakeClock
import tempfile
from pathlib import Path


class AuthTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "users.json"
        self.clock = FakeClock()
        self.store = UserStore(self.path)
        self.auth = AuthService(self.store, self.clock, iterations=10)

    def test_register_and_login(self):
        self.assertFalse(self.auth.accounts_exist())
        self.assertEqual(self.auth.register("  Alice ", "s3cretpass"),
                         "alice")
        self.assertTrue(self.auth.accounts_exist())
        self.assertEqual(self.auth.authenticate("ALICE", "s3cretpass"),
                         "alice")

    def test_password_is_hashed_never_plaintext(self):
        self.auth.register("alice", "s3cretpass")
        raw = self.path.read_text()
        self.assertNotIn("s3cretpass", raw)
        record = json.loads(raw)["users"]["alice"]
        self.assertEqual(len(record["salt"]), 32)
        self.assertEqual(len(record["hash"]), 64)

    def test_same_password_gets_different_salt_and_hash(self):
        self.auth.register("alice", "s3cretpass")
        self.auth.register("bobby", "s3cretpass")
        a, b = (self.store.get(n) for n in ("alice", "bobby"))
        self.assertNotEqual(a["salt"], b["salt"])
        self.assertNotEqual(a["hash"], b["hash"])

    def test_duplicate_username_rejected(self):
        self.auth.register("alice", "s3cretpass")
        with self.assertRaises(ValidationError):
            self.auth.register("ALICE", "an0therpass")

    def test_wrong_password_and_unknown_user_look_identical(self):
        self.auth.register("alice", "s3cretpass")
        for name, pw in (("alice", "wrongpass1"), ("nobody", "whatever1"),
                         ("../etc", "x"), (None, "x")):
            with self.assertRaises(AuthError) as ctx:
                self.auth.authenticate(name, pw)
            self.assertEqual(str(ctx.exception), GENERIC_FAILURE)

    def test_lockout_and_expiry(self):
        self.auth.register("alice", "s3cretpass")
        for _ in range(5):
            with self.assertRaises(AuthError):
                self.auth.authenticate("alice", "badpass123")
        with self.assertRaises(AuthError) as ctx:  # even correct pw blocked
            self.auth.authenticate("alice", "s3cretpass")
        self.assertIn("Too many failed attempts", str(ctx.exception))
        self.clock.advance(minutes=6)
        self.assertEqual(self.auth.authenticate("alice", "s3cretpass"),
                         "alice")

    def test_success_resets_failure_counter(self):
        self.auth.register("alice", "s3cretpass")
        for _ in range(4):
            with self.assertRaises(AuthError):
                self.auth.authenticate("alice", "badpass123")
        self.auth.authenticate("alice", "s3cretpass")
        for _ in range(4):  # would lock if the counter had not reset
            with self.assertRaises(AuthError) as ctx:
                self.auth.authenticate("alice", "badpass123")
            self.assertEqual(str(ctx.exception), GENERIC_FAILURE)

    def test_change_password(self):
        self.auth.register("alice", "s3cretpass")
        self.auth.change_password("alice", "s3cretpass", "n3wpassword")
        with self.assertRaises(AuthError):
            self.auth.authenticate("alice", "s3cretpass")
        self.assertEqual(self.auth.authenticate("alice", "n3wpassword"),
                         "alice")
        with self.assertRaises(AuthError):
            self.auth.change_password("alice", "wrong", "an0therpass")

    def test_username_rules(self):
        self.assertEqual(validate_username("A.b-c_9"), "a.b-c_9")
        for bad in ("ab", "x" * 31, "../evil", "a/b", "a b", ".hidden",
                    "a..b", "", None, 5):
            with self.assertRaises(ValidationError):
                validate_username(bad)

    def test_password_rules(self):
        validate_password("goodpass1", "alice")
        for bad in ("short1", "alllettersss", "12345678", "x" * 129,
                    "alice12345", None):
            with self.assertRaises(ValidationError):
                validate_password(bad, "alice")

    def test_state_persists_across_restart(self):
        self.auth.register("alice", "s3cretpass")
        again = AuthService(UserStore(self.path), self.clock, iterations=10)
        self.assertEqual(again.authenticate("alice", "s3cretpass"), "alice")

    def test_corrupt_accounts_file_is_not_silently_discarded(self):
        self.path.write_text("{garbage", encoding="utf-8")
        with self.assertRaises(StorageError):
            UserStore(self.path)
        self.assertEqual(self.path.read_text(), "{garbage")  # untouched

    def test_accounts_file_is_owner_only(self):
        import os
        import stat
        self.auth.register("alice", "s3cretpass")
        if os.name == "posix":
            mode = stat.S_IMODE(os.stat(self.path).st_mode)
            self.assertEqual(mode, 0o600)


if __name__ == "__main__":
    unittest.main()
