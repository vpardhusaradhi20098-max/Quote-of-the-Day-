import contextlib
import io
import unittest

from quote_app.presentation import cli
from tests.helpers import ZEN_TODAY, ServiceTestCase


class CliTests(ServiceTestCase):
    def run_cli(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        code = cli.run(list(argv), self.service, out, err)
        return code, out.getvalue(), err.getvalue()

    def test_today(self):
        self.http.responses[ZEN_TODAY] = [
            {"q": "CLI quote here", "a": "Tester"}]
        code, out, _ = self.run_cli("today")
        self.assertEqual(code, 0)
        self.assertIn("CLI quote here", out)
        self.assertIn("(source: api)", out)

    def test_add_search_rate_note_favorite_show_stats(self):
        code, out, _ = self.run_cli("add", "Testing is caring", "--author",
                                    "Dev", "--tags", "qa")
        self.assertEqual(code, 0)
        qid = out.split()[-1].rstrip(".")
        self.assertEqual(self.run_cli("rate", qid, "5")[0], 0)
        self.assertEqual(self.run_cli("note", qid, "so true")[0], 0)
        self.assertIn("on", self.run_cli("favorite", qid)[1])
        code, out, _ = self.run_cli("search", "caring", "--min-rating", "5")
        self.assertIn("1 quote(s).", out)
        code, out, _ = self.run_cli("show", qid)
        self.assertIn("so true", out)
        code, out, _ = self.run_cli("stats")
        self.assertIn("Average rating:  5.00 / 5", out)

    def test_errors_return_exit_code_1(self):
        code, _, err = self.run_cli("rate", "missing", "3")
        self.assertEqual(code, 1)
        self.assertIn("not found", err)
        code, _, err = self.run_cli("add", "x")
        self.assertEqual(code, 1)

    def test_delete_requires_confirmation(self):
        qid = self.service.add_manual_quote("Delete me please", "x").id
        self.assertEqual(self.run_cli("delete", qid)[0], 1)
        self.assertEqual(self.run_cli("delete", qid, "--yes")[0], 0)
        self.assertIn("No quotes found.", self.run_cli("list")[1])

    def test_export_import(self):
        self.service.add_manual_quote("Export via cli", "x")
        path = str(self.dir / "q.csv")
        code, out, _ = self.run_cli("export", path, "--observations",
                                    str(self.dir / "o.csv"))
        self.assertIn("Exported 1 quote(s).", out)
        code, out, _ = self.run_cli("import", path)
        self.assertIn("Imported 0, skipped 1.", out)

    def test_usage_errors_exit_2(self):
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                cli.run([], self.service, io.StringIO(), io.StringIO())
        self.assertEqual(ctx.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
