# Quote of the Day

A desktop and command-line application that shows an inspiring quote every
day, lets you build a personal quote library, and gives you analytics about
your reading habits.

* **Language:** Python 3.8+ - standard library only, nothing to install
* **Interfaces:** Tkinter GUI **and** a full CLI
* **Architecture:** strict 3-tier (presentation / business / data)
* **Storage:** SQLite (default) or JSON - interchangeable behind one interface
* **Accounts:** optional, password-protected, per-user data isolation
* **Tests:** 153 automated tests (`unittest`), ~97% line coverage outside the GUI

## Quick start

```bash
python main.py            # launch the GUI
python main.py today      # CLI: today's quote
python main.py --help     # every CLI command
python -m unittest discover -s tests -t .      # run the tests
```

On Linux you may need Tkinter: `sudo apt install python3-tk`.
Without Tkinter the CLI still works fully.

## Features

| Area | What it does |
|------|--------------|
| **Quote API** | Fetches today's/random quotes from two keyless public providers (ZenQuotes, DummyJSON) with timeout, retry + exponential backoff, provider failover and response-size cap. HTTPS only. |
| **Offline mode** | If every provider fails, a built-in quote is chosen deterministically from the date, so the app always works. |
| **Quote of the day** | Fetched once per day, then cached - reopening the app never re-calls the API. "Refresh" retries the API on demand. |
| **Persistence** | SQLite database (foreign keys, cascade deletes, transactions, CHECK constraints) by default; JSON backend via `QOTD_STORAGE=json`. Both recover from corrupt files. CSV export (quotes + activity) and validated CSV import. |
| **Accounts** | Optional. `python main.py register NAME` creates a password-protected account; afterwards login is required (`--user NAME` on the CLI, a login dialog in the GUI) and each user's data lives in its own folder. |
| **Search** | Multi-word AND search across text, author and tags; filters for author, tag, favorites, minimum rating; sort by newest / oldest / author / rating / views. |
| **Your own quotes** | Add quotes with author and tags; duplicates are detected. |
| **Engagement** | Favorites, 1-5 ratings (latest wins), personal notes, per-quote activity history. |
| **Analytics** | Totals, unique authors, average words, views, rating distribution + average, top authors/tags, most-viewed quotes, views per day, current and longest daily streak. GUI also draws a ratings chart. |

## Architecture

```
 +-------------------------------------------------------------+
 |  PRESENTATION TIER          quote_app/presentation/         |
 |  gui.py (Tkinter)   cli.py (argparse)   formatting.py       |
 +------------------------------+------------------------------+
                                | calls QuoteService only
 +------------------------------v------------------------------+
 |  BUSINESS TIER              quote_app/business/             |
 |  services.py    use-cases: daily quote, search, rate, CSV   |
 |  validation.py  every input is cleaned and bounded here     |
 |  auth.py        PBKDF2 hashing, lockout, registration       |
 |  analytics.py   pure functions, no I/O                      |
 +------------------------------+------------------------------+
                                | repository / client / csv
 +------------------------------v------------------------------+
 |  DATA ACCESS TIER           quote_app/data/                 |
 |  repository_base.py  abstract QuoteRepository interface     |
 |  sqlite_repository.py (default)   repository.py (JSON)      |
 |  api_client.py  remote API        csv_store.py  CSV I/O     |
 |  user_store.py  accounts file     fallback_quotes.py        |
 +-------------------------------------------------------------+
        models.py (domain)   errors.py   config.py   bootstrap.py
```

Rules that keep the tiers honest:

* Presentation never touches files or the network; it only calls `QuoteService`.
* Business logic never imports Tkinter or `argparse`.
* The data tier knows nothing about validation rules or the UI.
* `bootstrap.py` is the single composition root; every dependency
  (HTTP function, clock, RNG, storage path) is injectable, which is why the
  tests need no network, no real clock and no real home directory.

## Data design

Master/detail model (see `quote_app/models.py`):

```
PrimaryRecord (id, created_at)              DetailObservation (obs_id, parent_id,
   |                                                           timestamp, kind)
   +-- Quote (text, author, tags,                |
   |          source, is_favorite)               +-- QuoteObservation (rating, note)
   |                                                      kind: view | rating | note
   +------------- 1 ---------------- * ------------------- favorite | unfavorite
```

* **`Quote`** (the `PrimaryRecord`) has a deterministic id - a hash of the
  normalised text + author - so the same quote can never be stored twice.
* **`QuoteObservation`** (the `DetailObservation`) is an append-only event.
  Because history is never overwritten, streaks, views-per-day and rating
  history all fall out of simple aggregation.
* Deleting a quote cascades to its observations and daily-quote mapping.

SQLite schema (`data/quotes.db`): tables `quotes`, `observations`
(`parent_id REFERENCES quotes ON DELETE CASCADE`, `rating CHECK 1..5`),
`daily` and `meta`; all queries are parameterised. The JSON backend
(`data/quotes.json`) stores the same data:

```json
{ "version": 1,
  "quotes":       [ { "id": "...", "text": "...", "author": "...", "tags": [], ... } ],
  "observations": [ { "obs_id": "...", "parent_id": "<quote id>", "kind": "view", ... } ],
  "daily":        { "2026-11-26": "<quote id>" } }
```

## Security and robustness

* **Input validation** - all text is stripped of control characters,
  whitespace-normalised and length-limited; tags are whitelisted
  (`[a-z0-9 _-]`); ratings must be whole numbers 1-5. The same validators
  protect GUI, CLI, CSV import and API responses.
* **CSV formula injection** - cells starting with `= + - @` are neutralised on
  export and restored on import.
* **Network** - HTTPS only, 8 s timeout, 1 MB response cap, strict payload
  parsing, rate-limit placeholder detection. No API keys exist, so there are
  no secrets to leak.
* **Authentication** - salted PBKDF2-HMAC-SHA256 (200,000 iterations),
  constant-time comparison, account lockout after 5 failures (5 minutes),
  one generic error message (no username enumeration), strong-password rules,
  owner-only permissions on the accounts file. A corrupt accounts file is
  never auto-replaced, because that would silently disable protection.
* **SQL injection** - impossible by construction (parameterised statements,
  and a test stores `'); DROP TABLE quotes;--` as plain text).
* **Storage** - JSON writes are atomic (temp file + `os.replace`); SQLite
  writes are transactions. A corrupt data file is moved aside
  (`*.corrupt-<time>`) and the app starts fresh instead of crashing; CSV imports are capped at 5 MB / 10,000 rows.
* **Error handling** - every deliberate failure is a `QuoteAppError` subclass;
  the GUI shows a dialog, the CLI prints `Error: ...` and exits 1.
* **Concurrency** - network calls run on worker threads; the repository is
  guarded by a re-entrant lock.
* **Logging** - rotating log file at `data/app.log`.

## CLI reference

```
python main.py today [--refresh]
python main.py random
python main.py add "text" [--author NAME] [--tags "a, b"]
python main.py search [QUERY] [--author A] [--tag T] [--favorites]
                      [--min-rating N] [--sort newest|oldest|author|rating|views]
python main.py list   [same filters]
python main.py show ID          # quote + activity history
python main.py favorite ID
python main.py rate ID 1-5
python main.py note ID "text"
python main.py delete ID --yes
python main.py stats
python main.py register NAME                  # optional accounts
python main.py --user NAME <any command above>
python main.py export quotes.csv [--observations activity.csv]
python main.py import quotes.csv
```

Example:

```
$ python main.py today
"Not all those who wander are lost."
  - J.R.R. Tolkien
  [id 814e928bfdea | rating - | views 1 | tags: adventure]
(source: offline)
```

Environment variables: `QOTD_DATA_DIR` (data location, default `./data`),
`QOTD_STORAGE` (`sqlite` or `json`), `QOTD_PASSWORD` (non-interactive
login for scripts).

## Testing

```bash
python -m unittest discover -s tests -t .
```

| File | Covers |
|------|--------|
| `test_models.py` | ids, serialisation round-trips, invalid records |
| `test_validation.py` | every validator and its limits |
| `test_api_client.py` | parsers, failover, retry/backoff, bad JSON, rate limits |
| `test_http_and_main.py` | HTTPS-only, size cap, full stack with network blocked |
| `test_repository_contract.py` | one shared suite run against **both** backends: persistence, dedupe, ordering, cascade delete, unicode, SQL-injection text, 4-thread concurrency |
| `test_repository.py` | backend-specific: corruption quarantine, FK/CHECK constraints, error mapping |
| `test_services_sqlite.py` | the entire service suite re-run on SQLite |
| `test_auth.py` | hashing, salts, lockout + expiry, no enumeration, password/username rules, corrupt accounts file |
| `test_services.py` | daily-quote caching, offline fallback, search, sort, ratings, CSV |
| `test_analytics.py` | streak maths, aggregate report |
| `test_cli.py` | every CLI command, exit codes |

The suite runs in a few seconds and never touches the real network. A GitHub
Actions workflow (`.github/workflows/tests.yml`) runs it on Python 3.9, 3.11
and 3.12.

## Project layout

```
quote_of_the_day/
  main.py                   entry point (GUI or CLI)
  quote_app/
    models.py errors.py config.py bootstrap.py
    data/          repository_base.py sqlite_repository.py repository.py
                   user_store.py api_client.py csv_store.py fallback_quotes.py
    business/      services.py validation.py analytics.py auth.py
    presentation/  gui.py cli.py auth_cli.py formatting.py
  tests/
  data/                     created at runtime (database, accounts, log)
```

## Known limitations

* Search filters in Python after loading the library, which is fine for
  thousands of quotes; moving filters into SQL `WHERE` clauses would be the
  next step for much larger libraries.
* Accounts protect the app's own data folders, not the files themselves: this
  is a local desktop app, so someone with disk access can still read the
  database. Use OS-level disk encryption for that.
* Accounts are created from the command line (`register`), not the GUI.
