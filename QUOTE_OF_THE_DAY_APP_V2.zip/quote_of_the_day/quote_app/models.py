"""Domain model.

The data design follows a classic master/detail layout:

* ``PrimaryRecord``  - an entity that exists on its own. ``Quote`` is the
  concrete primary record.
* ``DetailObservation`` - an append-only event that belongs to exactly one
  primary record (one-to-many). ``QuoteObservation`` records views, ratings,
  notes and favourite toggles for a quote.

Keeping observations as an event log (instead of overwriting fields) is what
makes analytics such as streaks, views-per-day and rating history possible.
"""
import hashlib
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from .errors import DataError


class ObservationKind:
    """Allowed values for ``DetailObservation.kind``."""
    VIEW = "view"
    RATING = "rating"
    NOTE = "note"
    FAVORITE = "favorite"
    UNFAVORITE = "unfavorite"

    ALL = (VIEW, RATING, NOTE, FAVORITE, UNFAVORITE)


class QuoteSource:
    """Where a quote came from."""
    API = "api"
    OFFLINE = "offline"
    MANUAL = "manual"
    IMPORT = "import"

    ALL = (API, OFFLINE, MANUAL, IMPORT)


def now_iso(moment: Optional[datetime] = None) -> str:
    """Return a timestamp string with second precision."""
    return (moment or datetime.now()).isoformat(timespec="seconds")


def make_quote_id(text: str, author: str) -> str:
    """Deterministic id so the same quote is never stored twice."""
    normalized = "{}|{}".format(" ".join(text.lower().split()),
                                " ".join(author.lower().split()))
    return hashlib.sha1(normalized.encode("utf-8")).hexdigest()[:12]


@dataclass
class PrimaryRecord:
    """Base class for top-level entities."""
    id: str
    created_at: str


@dataclass
class Quote(PrimaryRecord):
    """A single quotation."""
    text: str = ""
    author: str = "Unknown"
    tags: List[str] = field(default_factory=list)
    source: str = QuoteSource.MANUAL
    is_favorite: bool = False

    @classmethod
    def create(cls, text: str, author: str, tags: Optional[List[str]] = None,
               source: str = QuoteSource.MANUAL,
               moment: Optional[datetime] = None) -> "Quote":
        """Build a new quote with a deterministic id."""
        return cls(id=make_quote_id(text, author), created_at=now_iso(moment),
                   text=text, author=author, tags=list(tags or []),
                   source=source)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Quote":
        try:
            tags = data.get("tags", [])
            if not isinstance(tags, list):
                raise TypeError("tags must be a list")
            return cls(id=str(data["id"]), created_at=str(data["created_at"]),
                       text=str(data["text"]), author=str(data["author"]),
                       tags=[str(t) for t in tags],
                       source=str(data.get("source", QuoteSource.MANUAL)),
                       is_favorite=bool(data.get("is_favorite", False)))
        except (KeyError, TypeError, AttributeError) as exc:
            raise DataError("Invalid quote record: {}".format(exc)) from exc


@dataclass
class DetailObservation:
    """Base class for events that belong to one primary record."""
    obs_id: str
    parent_id: str
    timestamp: str
    kind: str


@dataclass
class QuoteObservation(DetailObservation):
    """An event about a quote: a view, rating, note or favourite toggle."""
    rating: Optional[int] = None
    note: str = ""

    @classmethod
    def create(cls, quote_id: str, kind: str, rating: Optional[int] = None,
               note: str = "",
               moment: Optional[datetime] = None) -> "QuoteObservation":
        if kind not in ObservationKind.ALL:
            raise DataError("Unknown observation kind: {}".format(kind))
        return cls(obs_id=uuid.uuid4().hex[:12], parent_id=quote_id,
                   timestamp=now_iso(moment), kind=kind, rating=rating,
                   note=note)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QuoteObservation":
        try:
            kind = str(data["kind"])
            if kind not in ObservationKind.ALL:
                raise ValueError("unknown kind {!r}".format(kind))
            rating = data.get("rating")
            if rating is not None:
                rating = int(rating)
            datetime.fromisoformat(str(data["timestamp"]))
            return cls(obs_id=str(data["obs_id"]),
                       parent_id=str(data["parent_id"]),
                       timestamp=str(data["timestamp"]), kind=kind,
                       rating=rating, note=str(data.get("note", "")))
        except (KeyError, TypeError, ValueError, AttributeError) as exc:
            raise DataError(
                "Invalid observation record: {}".format(exc)) from exc
