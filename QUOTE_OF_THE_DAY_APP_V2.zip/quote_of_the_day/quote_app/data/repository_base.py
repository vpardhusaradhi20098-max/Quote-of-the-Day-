"""Abstract repository contract (data tier).

The business tier depends only on this interface, so storage backends
(JSON file, SQLite) are interchangeable without touching any other code.
Every backend must pass the shared contract tests in
``tests/test_repository_contract.py``.
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

from ..models import Quote, QuoteObservation


class QuoteRepository(ABC):
    """Storage for quotes (primary records) and observations (details)."""

    @abstractmethod
    def add_quote(self, quote: Quote) -> Tuple[Quote, bool]:
        """Insert a quote; returns ``(stored_quote, created)``."""

    @abstractmethod
    def get_quote(self, quote_id: str) -> Optional[Quote]:
        """Return a copy of the quote or ``None``."""

    @abstractmethod
    def all_quotes(self) -> List[Quote]:
        """Return copies of every quote in insertion order."""

    @abstractmethod
    def update_quote(self, quote: Quote) -> None:
        """Replace a stored quote; raises ``NotFoundError`` if absent."""

    @abstractmethod
    def delete_quote(self, quote_id: str) -> bool:
        """Delete a quote and cascade to its observations and daily slot."""

    @abstractmethod
    def add_observation(self, observation: QuoteObservation) -> None:
        """Append an observation; the parent quote must exist."""

    @abstractmethod
    def observations(self, quote_id: Optional[str] = None
                     ) -> List[QuoteObservation]:
        """Observations in insertion order, optionally for one quote."""

    @abstractmethod
    def get_daily(self, day: str) -> Optional[str]:
        """Quote id chosen for ``day`` (ISO date) or ``None``."""

    @abstractmethod
    def set_daily(self, day: str, quote_id: str) -> None:
        """Remember today's quote; the quote must exist."""

    def close(self) -> None:
        """Release resources. Safe to call more than once."""
