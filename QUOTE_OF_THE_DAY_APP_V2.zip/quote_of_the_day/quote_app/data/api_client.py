"""Remote quote API client (data tier).

Two keyless public providers are tried in order. Every failure mode -
network error, timeout, bad JSON, rate-limit placeholder, oversized or
malformed payload - is converted into a single ``ApiError`` so the business
tier can fall back to the built-in quotes.

The HTTP layer is injectable (``http_get``) which keeps the client fully
unit-testable without touching the network.
"""
import json
import logging
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, List, Tuple

from .. import config
from ..errors import ApiError

LOG = logging.getLogger(__name__)

HttpGet = Callable[[str, float], bytes]


@dataclass(frozen=True)
class RawQuote:
    """A quote exactly as returned by a provider (not yet validated)."""
    text: str
    author: str
    provider: str


def default_http_get(url: str, timeout: float) -> bytes:
    """Fetch ``url`` over HTTPS with a size cap."""
    if not url.lower().startswith("https://"):
        raise ApiError("Refusing non-HTTPS URL")
    request = urllib.request.Request(
        url, headers={"User-Agent": "QuoteOfTheDay/1.0",
                      "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        body = response.read(config.MAX_RESPONSE_BYTES + 1)
    if len(body) > config.MAX_RESPONSE_BYTES:
        raise ApiError("Response too large")
    return body


def parse_zenquotes(payload: Any) -> RawQuote:
    """Parse ``[{"q": text, "a": author}]`` from zenquotes.io."""
    if not isinstance(payload, list) or not payload:
        raise ApiError("Unexpected zenquotes payload")
    item = payload[0]
    if not isinstance(item, dict):
        raise ApiError("Unexpected zenquotes item")
    text, author = item.get("q"), item.get("a")
    if not isinstance(text, str) or not isinstance(author, str):
        raise ApiError("Missing fields in zenquotes item")
    if author.strip().lower() == "zenquotes.io":
        raise ApiError("zenquotes rate limit placeholder")
    return RawQuote(text, author, "zenquotes")


def parse_dummyjson(payload: Any) -> RawQuote:
    """Parse ``{"quote": text, "author": author}`` from dummyjson.com."""
    if not isinstance(payload, dict):
        raise ApiError("Unexpected dummyjson payload")
    text, author = payload.get("quote"), payload.get("author")
    if not isinstance(text, str) or not isinstance(author, str):
        raise ApiError("Missing fields in dummyjson payload")
    return RawQuote(text, author, "dummyjson")


Provider = Tuple[str, str, Callable[[Any], RawQuote]]

TODAY_PROVIDERS: List[Provider] = [
    ("zenquotes", "https://zenquotes.io/api/today", parse_zenquotes),
    ("dummyjson", "https://dummyjson.com/quotes/random", parse_dummyjson),
]
RANDOM_PROVIDERS: List[Provider] = [
    ("zenquotes", "https://zenquotes.io/api/random", parse_zenquotes),
    ("dummyjson", "https://dummyjson.com/quotes/random", parse_dummyjson),
]


class QuoteApiClient:
    """Fetches quotes from remote providers with retry and failover."""

    def __init__(self, http_get: HttpGet = default_http_get,
                 timeout: float = config.API_TIMEOUT_SECONDS,
                 retries: int = config.API_RETRIES,
                 backoff: float = config.API_BACKOFF_SECONDS,
                 sleep: Callable[[float], None] = time.sleep) -> None:
        self._http_get = http_get
        self._timeout = timeout
        self._retries = max(0, retries)
        self._backoff = backoff
        self._sleep = sleep

    def fetch_today(self) -> RawQuote:
        """Return the provider's quote of the day."""
        return self._fetch(TODAY_PROVIDERS)

    def fetch_random(self) -> RawQuote:
        """Return a random quote."""
        return self._fetch(RANDOM_PROVIDERS)

    def _fetch(self, providers: List[Provider]) -> RawQuote:
        last_error = "no providers configured"
        for name, url, parser in providers:
            for attempt in range(self._retries + 1):
                try:
                    body = self._http_get(url, self._timeout)
                    return parser(json.loads(body.decode("utf-8")))
                except (ApiError, urllib.error.URLError, OSError,
                        ValueError) as exc:
                    # ValueError covers JSONDecodeError and bad UTF-8.
                    last_error = "{}: {}".format(name, exc)
                    LOG.warning("Provider %s attempt %d failed: %s",
                                name, attempt + 1, exc)
                    if attempt < self._retries:
                        self._sleep(self._backoff * (2 ** attempt))
        raise ApiError("All quote providers failed ({})".format(last_error))
