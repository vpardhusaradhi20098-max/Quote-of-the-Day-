"""Built-in quotes used when the remote API is unreachable.

Each entry is (text, author, tags). Authors are historical figures or
well-documented sources so the app works fully offline.
"""
from typing import List, Tuple

FallbackQuote = Tuple[str, str, List[str]]

FALLBACK_QUOTES: List[FallbackQuote] = [
    ("The unexamined life is not worth living.", "Socrates",
     ["philosophy", "wisdom"]),
    ("I think, therefore I am.", "Rene Descartes", ["philosophy"]),
    ("Not all those who wander are lost.", "J.R.R. Tolkien",
     ["adventure"]),
    ("If I have seen further it is by standing on the shoulders of giants.",
     "Isaac Newton", ["science", "humility"]),
    ("Genius is one percent inspiration and ninety-nine percent "
     "perspiration.", "Thomas Edison", ["work", "invention"]),
    ("Imagination is more important than knowledge.", "Albert Einstein",
     ["creativity", "science"]),
    ("Nothing in life is to be feared, it is only to be understood.",
     "Marie Curie", ["science", "courage"]),
    ("It does not matter how slowly you go as long as you do not stop.",
     "Confucius", ["perseverance"]),
    ("The journey of a thousand miles begins with a single step.",
     "Lao Tzu", ["beginnings", "perseverance"]),
    ("Well done is better than well said.", "Benjamin Franklin",
     ["action"]),
    ("An investment in knowledge pays the best interest.",
     "Benjamin Franklin", ["learning"]),
    ("The only thing we have to fear is fear itself.",
     "Franklin D. Roosevelt", ["courage"]),
    ("Do what you can, with what you have, where you are.",
     "Theodore Roosevelt", ["action"]),
    ("Courage is grace under pressure.", "Ernest Hemingway", ["courage"]),
    ("Education is the most powerful weapon which you can use to change "
     "the world.", "Nelson Mandela", ["education", "change"]),
    ("Waste no more time arguing about what a good man should be. "
     "Be one.", "Marcus Aurelius", ["philosophy", "action"]),
    ("Fall seven times, stand up eight.", "Japanese Proverb",
     ["perseverance", "resilience"]),
    ("The best way to predict the future is to invent it.", "Alan Kay",
     ["technology", "creativity"]),
    ("Simple things should be simple, complex things should be possible.",
     "Alan Kay", ["technology", "design"]),
    ("Programs must be written for people to read, and only incidentally "
     "for machines to execute.", "Harold Abelson",
     ["programming", "clarity"]),
    ("Premature optimization is the root of all evil.", "Donald Knuth",
     ["programming"]),
    ("Talk is cheap. Show me the code.", "Linus Torvalds",
     ["programming", "action"]),
    ("Any fool can write code that a computer can understand. Good "
     "programmers write code that humans can understand.", "Martin Fowler",
     ["programming", "clarity"]),
    ("Make it work, make it right, make it fast.", "Kent Beck",
     ["programming", "craft"]),
]
