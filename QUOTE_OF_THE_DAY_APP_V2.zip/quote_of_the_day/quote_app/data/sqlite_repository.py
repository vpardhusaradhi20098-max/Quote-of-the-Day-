"""SQLite repository (data tier) - the default storage backend.

* Real relational schema with foreign keys and ``ON DELETE CASCADE``.
* Every statement is parameterised, so SQL injection is impossible.
* Each mutation runs inside a transaction (``with connection``).
* A file that is not a valid database is quarantined instead of crashing
  the app; genuine I/O problems (permissions, full disk) are *not*
  quarantined, they surface as ``StorageError``.
"""
import json
import logging
import os
import sqlite3
import threading
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple

from ..errors import DataError, NotFoundError, StorageError
from ..models import Quote, QuoteObservation
from .repository_base import QuoteRepository

LOG = logging.getLogger(__name__)

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS quotes (
    id          TEXT PRIMARY KEY,
    created_at  TEXT NOT NULL,
    text        TEXT NOT NULL,
    author      TEXT NOT NULL,
    tags        TEXT NOT NULL DEFAULT '[]',
    source      TEXT NOT NULL,
    is_favorite INTEGER NOT NULL DEFAULT 0 CHECK (is_favorite IN (0, 1)));
CREATE TABLE IF NOT EXISTS observations (
    obs_id    TEXT PRIMARY KEY,
    parent_id TEXT NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
    timestamp TEXT NOT NULL,
    kind      TEXT NOT NULL,
    rating    INTEGER CHECK (rating IS NULL OR rating BETWEEN 1 AND 5),
    note      TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS idx_obs_parent ON observations(parent_id);
CREATE TABLE IF NOT EXISTS daily (
    day      TEXT PRIMARY KEY,
    quote_id TEXT NOT NULL REFERENCES quotes(id) ON DELETE CASCADE);
"""


class SqliteRepository(QuoteRepository):
    """Stores quotes and observations in a SQLite database file."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._open()

    # ------------------------------------------------------- connection
    def _connect(self) -> sqlite3.Connection:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._path), check_same_thread=False)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _open(self) -> None:
        conn = None
        try:
            conn = self._connect()
            conn.executescript(_SCHEMA)
            conn.execute("INSERT OR IGNORE INTO meta VALUES (?, ?)",
                         ("schema_version", str(SCHEMA_VERSION)))
            conn.commit()
            self._conn = conn
        except sqlite3.DatabaseError as exc:
            if conn is not None:
                conn.close()
            if (isinstance(exc, sqlite3.OperationalError)
                    and "malformed" not in str(exc)):
                raise StorageError(
                    "Cannot open {}: {}".format(self._path, exc)) from exc
            self._quarantine(exc)
            self._open()

    def _quarantine(self, reason: Exception) -> None:
        stamp = datetime.now().strftime("%Y%m%d%H%M%S")
        target = self._path.with_name(
            "{}.corrupt-{}".format(self._path.name, stamp))
        LOG.error("Database corrupt (%s); moving to %s", reason, target)
        try:
            os.replace(self._path, target)
        except OSError as exc:
            raise StorageError(
                "Database is corrupt and cannot be moved: {}".format(exc)
            ) from exc

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    def _run(self, work: Callable[[sqlite3.Connection], Any]) -> Any:
        """Run ``work`` in a transaction under the lock."""
        with self._lock:
            if self._conn is None:
                raise StorageError("Repository is closed")
            try:
                with self._conn:
                    return work(self._conn)
            except sqlite3.Error as exc:
                raise StorageError(
                    "Database error: {}".format(exc)) from exc

    # ------------------------------------------------------------ rows
    @staticmethod
    def _to_quote(row: Tuple[Any, ...]) -> Quote:
        try:
            tags = json.loads(row[4])
            if not isinstance(tags, list):
                raise ValueError("tags is not a list")
        except ValueError as exc:
            raise DataError("Invalid tags for quote {}".format(row[0])
                            ) from exc
        return Quote(id=row[0], created_at=row[1], text=row[2],
                     author=row[3], tags=[str(t) for t in tags],
                     source=row[5], is_favorite=bool(row[6]))

    _QUOTE_COLUMNS = ("id, created_at, text, author, tags, source, "
                      "is_favorite")

    # ------------------------------------------------------------ quotes
    def add_quote(self, quote: Quote) -> Tuple[Quote, bool]:
        def work(conn: sqlite3.Connection) -> Tuple[Quote, bool]:
            cursor = conn.execute(
                "INSERT OR IGNORE INTO quotes ({}) VALUES (?,?,?,?,?,?,?)"
                .format(self._QUOTE_COLUMNS),
                (quote.id, quote.created_at, quote.text, quote.author,
                 json.dumps(quote.tags), quote.source,
                 int(quote.is_favorite)))
            if cursor.rowcount == 1:
                return replace(quote, tags=list(quote.tags)), True
            row = conn.execute(
                "SELECT {} FROM quotes WHERE id = ?".format(
                    self._QUOTE_COLUMNS), (quote.id,)).fetchone()
            return self._to_quote(row), False
        return self._run(work)

    def get_quote(self, quote_id: str) -> Optional[Quote]:
        row = self._run(lambda c: c.execute(
            "SELECT {} FROM quotes WHERE id = ?".format(
                self._QUOTE_COLUMNS), (quote_id,)).fetchone())
        return self._to_quote(row) if row else None

    def all_quotes(self) -> List[Quote]:
        rows = self._run(lambda c: c.execute(
            "SELECT {} FROM quotes ORDER BY rowid".format(
                self._QUOTE_COLUMNS)).fetchall())
        return [self._to_quote(r) for r in rows]

    def update_quote(self, quote: Quote) -> None:
        def work(conn: sqlite3.Connection) -> int:
            return conn.execute(
                "UPDATE quotes SET created_at=?, text=?, author=?, tags=?, "
                "source=?, is_favorite=? WHERE id=?",
                (quote.created_at, quote.text, quote.author,
                 json.dumps(quote.tags), quote.source,
                 int(quote.is_favorite), quote.id)).rowcount
        if self._run(work) == 0:
            raise NotFoundError("Quote {} not found".format(quote.id))

    def delete_quote(self, quote_id: str) -> bool:
        return self._run(lambda c: c.execute(
            "DELETE FROM quotes WHERE id = ?", (quote_id,)).rowcount > 0)

    # ------------------------------------------------------ observations
    def _require_quote(self, conn: sqlite3.Connection,
                       quote_id: str) -> None:
        if conn.execute("SELECT 1 FROM quotes WHERE id = ?",
                        (quote_id,)).fetchone() is None:
            raise NotFoundError("Quote {} not found".format(quote_id))

    def add_observation(self, observation: QuoteObservation) -> None:
        def work(conn: sqlite3.Connection) -> None:
            self._require_quote(conn, observation.parent_id)
            conn.execute(
                "INSERT INTO observations "
                "(obs_id, parent_id, timestamp, kind, rating, note) "
                "VALUES (?,?,?,?,?,?)",
                (observation.obs_id, observation.parent_id,
                 observation.timestamp, observation.kind,
                 observation.rating, observation.note))
        self._run(work)

    def observations(self, quote_id: Optional[str] = None
                     ) -> List[QuoteObservation]:
        sql = ("SELECT obs_id, parent_id, timestamp, kind, rating, note "
               "FROM observations")
        params: Tuple[Any, ...] = ()
        if quote_id is not None:
            sql += " WHERE parent_id = ?"
            params = (quote_id,)
        rows = self._run(lambda c: c.execute(
            sql + " ORDER BY rowid", params).fetchall())
        return [QuoteObservation(obs_id=r[0], parent_id=r[1],
                                 timestamp=r[2], kind=r[3], rating=r[4],
                                 note=r[5]) for r in rows]

    # ------------------------------------------------------ quote of day
    def get_daily(self, day: str) -> Optional[str]:
        row = self._run(lambda c: c.execute(
            "SELECT quote_id FROM daily WHERE day = ?", (day,)).fetchone())
        return row[0] if row else None

    def set_daily(self, day: str, quote_id: str) -> None:
        def work(conn: sqlite3.Connection) -> None:
            self._require_quote(conn, quote_id)
            conn.execute("INSERT OR REPLACE INTO daily VALUES (?, ?)",
                         (day, quote_id))
        self._run(work)
