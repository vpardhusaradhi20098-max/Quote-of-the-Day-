"""JSON-file repository (data tier).

All records are kept in memory and written through to a single JSON file on
every mutation. Writes are atomic (temp file + ``os.replace``) so a crash can
never leave a half-written store, and a corrupt file is quarantined rather
than crashing the app. A re-entrant lock makes the repository safe to use
from the GUI's background threads.
"""
import json
import logging
import os
import tempfile
import threading
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..errors import DataError, NotFoundError, StorageError
from ..models import Quote, QuoteObservation
from .repository_base import QuoteRepository

LOG = logging.getLogger(__name__)

SCHEMA_VERSION = 1


class JsonRepository(QuoteRepository):
    """Stores quotes (primary records) and observations (details)."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._lock = threading.RLock()
        self._quotes: Dict[str, Quote] = {}
        self._observations: List[QuoteObservation] = []
        self._daily: Dict[str, str] = {}
        self._load()

    # ------------------------------------------------------------ loading
    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            with open(self._path, encoding="utf-8") as handle:
                raw = json.load(handle)
            if not isinstance(raw, dict):
                raise DataError("Root element must be an object")
            quotes = [Quote.from_dict(q) for q in raw.get("quotes", [])]
            observations = [QuoteObservation.from_dict(o)
                            for o in raw.get("observations", [])]
            daily = raw.get("daily", {})
            if not isinstance(daily, dict):
                raise DataError("'daily' must be an object")
        except (ValueError, TypeError, DataError) as exc:
            self._quarantine(exc)
            return
        except OSError as exc:
            raise StorageError(
                "Cannot read {}: {}".format(self._path, exc)) from exc
        self._quotes = {q.id: q for q in quotes}
        known = set(self._quotes)
        self._observations = [o for o in observations if o.parent_id in known]
        self._daily = {str(k): str(v) for k, v in daily.items()
                       if str(v) in known}

    def _quarantine(self, reason: Exception) -> None:
        stamp = datetime.now().strftime("%Y%m%d%H%M%S")
        target = self._path.with_name(
            "{}.corrupt-{}".format(self._path.name, stamp))
        LOG.error("Data file corrupt (%s); moving to %s", reason, target)
        try:
            os.replace(self._path, target)
        except OSError as exc:
            raise StorageError(
                "Data file is corrupt and cannot be moved: {}".format(exc)
            ) from exc

    # ------------------------------------------------------------ saving
    def _persist(self) -> None:
        payload = {
            "version": SCHEMA_VERSION,
            "quotes": [q.to_dict() for q in self._quotes.values()],
            "observations": [o.to_dict() for o in self._observations],
            "daily": self._daily,
        }
        temp_name = None
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(
                dir=str(self._path.parent), prefix=".tmp-", suffix=".json")
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
            os.replace(temp_name, self._path)
        except OSError as exc:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)
            raise StorageError(
                "Cannot save {}: {}".format(self._path, exc)) from exc

    # ------------------------------------------------------------ quotes
    def add_quote(self, quote: Quote) -> Tuple[Quote, bool]:
        """Insert a quote. Returns ``(stored_quote, created)``."""
        with self._lock:
            existing = self._quotes.get(quote.id)
            if existing is not None:
                return self._copy(existing), False
            self._quotes[quote.id] = self._copy(quote)
            self._persist()
            return self._copy(quote), True

    def get_quote(self, quote_id: str) -> Optional[Quote]:
        with self._lock:
            found = self._quotes.get(quote_id)
            return self._copy(found) if found else None

    def all_quotes(self) -> List[Quote]:
        with self._lock:
            return [self._copy(q) for q in self._quotes.values()]

    def update_quote(self, quote: Quote) -> None:
        with self._lock:
            if quote.id not in self._quotes:
                raise NotFoundError("Quote {} not found".format(quote.id))
            self._quotes[quote.id] = self._copy(quote)
            self._persist()

    def delete_quote(self, quote_id: str) -> bool:
        """Delete a quote and cascade to its observations."""
        with self._lock:
            if quote_id not in self._quotes:
                return False
            del self._quotes[quote_id]
            self._observations = [o for o in self._observations
                                  if o.parent_id != quote_id]
            self._daily = {d: q for d, q in self._daily.items()
                           if q != quote_id}
            self._persist()
            return True

    # ------------------------------------------------------ observations
    def add_observation(self, observation: QuoteObservation) -> None:
        with self._lock:
            if observation.parent_id not in self._quotes:
                raise NotFoundError(
                    "Quote {} not found".format(observation.parent_id))
            self._observations.append(replace(observation))
            self._persist()

    def observations(self, quote_id: Optional[str] = None
                     ) -> List[QuoteObservation]:
        with self._lock:
            return [replace(o) for o in self._observations
                    if quote_id is None or o.parent_id == quote_id]

    # ------------------------------------------------------ quote of day
    def get_daily(self, day: str) -> Optional[str]:
        with self._lock:
            return self._daily.get(day)

    def set_daily(self, day: str, quote_id: str) -> None:
        with self._lock:
            if quote_id not in self._quotes:
                raise NotFoundError("Quote {} not found".format(quote_id))
            self._daily[day] = quote_id
            self._persist()

    @staticmethod
    def _copy(quote: Quote) -> Quote:
        return replace(quote, tags=list(quote.tags))
