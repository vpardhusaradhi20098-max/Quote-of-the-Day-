"""Persistence for user accounts (data tier).

Unlike the quote stores, a corrupt accounts file is **never** quarantined
and replaced: silently discarding every account would switch the app back to
unprotected mode. The error is raised so the user can restore the file.
"""
import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..errors import StorageError


class UserStore:
    """JSON file of ``{username: record}`` with atomic writes."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._lock = threading.RLock()
        self._users: Dict[str, Dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            with open(self._path, encoding="utf-8") as handle:
                raw = json.load(handle)
            users = raw["users"]
            if not isinstance(users, dict) or not all(
                    isinstance(v, dict) for v in users.values()):
                raise ValueError("'users' must map names to objects")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise StorageError(
                "Accounts file {} is unreadable ({}); restore it from a "
                "backup rather than deleting it".format(self._path, exc)
            ) from exc
        self._users = users

    def _persist(self) -> None:
        temp_name = None
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(
                dir=str(self._path.parent), prefix=".tmp-", suffix=".json")
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({"version": 1, "users": self._users}, handle,
                          indent=2)
            os.replace(temp_name, self._path)
            try:
                os.chmod(self._path, 0o600)  # owner-only where supported
            except OSError:
                pass
        except OSError as exc:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)
            raise StorageError(
                "Cannot save accounts: {}".format(exc)) from exc

    def has_users(self) -> bool:
        with self._lock:
            return bool(self._users)

    def names(self) -> List[str]:
        with self._lock:
            return sorted(self._users)

    def get(self, username: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            record = self._users.get(username)
            return dict(record) if record is not None else None

    def put(self, username: str, record: Dict[str, Any]) -> None:
        with self._lock:
            self._users[username] = dict(record)
            self._persist()
