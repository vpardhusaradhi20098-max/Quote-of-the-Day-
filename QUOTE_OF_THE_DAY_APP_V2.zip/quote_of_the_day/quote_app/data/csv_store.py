"""CSV reading/writing with spreadsheet-formula-injection protection.

Cells beginning with ``= + - @`` (or tab / carriage return) are prefixed with
an apostrophe on export so that Excel or Sheets never evaluates them. The
prefix is removed again on import.
"""
import csv
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

from .. import config
from ..errors import StorageError

_DANGEROUS_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def sanitize_cell(value: object) -> str:
    """Neutralise formula injection for one exported cell."""
    text = "" if value is None else str(value)
    if text.startswith(_DANGEROUS_PREFIXES):
        return "'" + text
    return text


def unsanitize_cell(value: str) -> str:
    """Reverse :func:`sanitize_cell` on import."""
    if len(value) > 1 and value[0] == "'" and value[1] in "=+-@\t\r":
        return value[1:]
    return value


def write_rows(path: Path, fieldnames: Sequence[str],
               rows: Iterable[Dict[str, object]]) -> int:
    """Write rows to ``path``; returns the number of rows written."""
    count = 0
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(fieldnames))
            writer.writeheader()
            for row in rows:
                writer.writerow({k: sanitize_cell(row.get(k))
                                 for k in fieldnames})
                count += 1
    except OSError as exc:
        raise StorageError("Cannot write {}: {}".format(path, exc)) from exc
    return count


def read_rows(path: Path) -> List[Dict[str, str]]:
    """Read a CSV file with size and row-count limits."""
    path = Path(path)
    try:
        if path.stat().st_size > config.MAX_CSV_BYTES:
            raise StorageError("CSV file is too large")
        with open(path, newline="", encoding="utf-8-sig") as handle:
            rows: List[Dict[str, str]] = []
            for row in csv.DictReader(handle):
                if len(rows) >= config.MAX_CSV_ROWS:
                    raise StorageError("CSV has too many rows")
                rows.append({(k or "").strip(): unsanitize_cell(v or "")
                             for k, v in row.items()})
            return rows
    except (OSError, csv.Error, UnicodeDecodeError) as exc:
        raise StorageError("Cannot read {}: {}".format(path, exc)) from exc
