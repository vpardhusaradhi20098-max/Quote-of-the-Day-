"""Application-specific exceptions shared by all three tiers."""


class QuoteAppError(Exception):
    """Base class for every error the application raises on purpose."""


class ValidationError(QuoteAppError):
    """User or external input failed validation."""


class ApiError(QuoteAppError):
    """The remote quote API could not provide a usable quote."""


class StorageError(QuoteAppError):
    """Reading or writing local files failed."""


class DataError(QuoteAppError):
    """Stored data is structurally invalid."""


class NotFoundError(QuoteAppError):
    """A requested record does not exist."""


class AuthError(QuoteAppError):
    """Login failed or an account operation was rejected."""
