"""Composition root: wires the three tiers together."""
from pathlib import Path
from typing import Optional

from . import config
from .business.auth import AuthService
from .business.services import QuoteService
from .data.api_client import QuoteApiClient
from .data.repository import JsonRepository
from .data.repository_base import QuoteRepository
from .data.sqlite_repository import SqliteRepository
from .data.user_store import UserStore
from .errors import ValidationError


def build_repository(directory: Path) -> QuoteRepository:
    """Create the configured storage backend inside ``directory``."""
    backend = config.storage_backend()
    if backend == "sqlite":
        return SqliteRepository(directory / config.DB_FILE_NAME)
    if backend == "json":
        return JsonRepository(directory / config.DATA_FILE_NAME)
    raise ValidationError(
        "QOTD_STORAGE must be 'sqlite' or 'json', not '{}'".format(backend))


def build_auth_service() -> AuthService:
    return AuthService(UserStore(config.data_dir() / config.USERS_FILE_NAME))


def build_service(username: Optional[str] = None) -> QuoteService:
    """Create a service; with ``username`` the data is per-user isolated."""
    config.configure_logging()
    directory = (config.user_data_dir(username) if username
                 else config.data_dir())
    return QuoteService(build_repository(directory), QuoteApiClient())
