"""Plain-text formatting shared by the CLI and the GUI."""
from typing import List

from ..business.analytics import AnalyticsReport
from ..business.services import QuoteView
from ..models import QuoteObservation


def stars(rating) -> str:
    """Render a 1-5 rating as stars, or a dash when unrated."""
    if not rating:
        return "-"
    return "*" * rating + "." * (5 - rating)


def truncate(text: str, width: int) -> str:
    return text if len(text) <= width else text[:width - 3].rstrip() + "..."


def format_quote(view: QuoteView) -> str:
    quote = view.quote
    lines = ['"{}"'.format(quote.text), "  - {}".format(quote.author)]
    meta = ["id {}".format(quote.id), "rating {}".format(stars(view.rating)),
            "views {}".format(view.views)]
    if quote.is_favorite:
        meta.append("favorite")
    if quote.tags:
        meta.append("tags: " + ", ".join(quote.tags))
    lines.append("  [" + " | ".join(meta) + "]")
    return "\n".join(lines)


def format_history(observations: List[QuoteObservation]) -> str:
    if not observations:
        return "No activity yet."
    lines = []
    for obs in observations:
        detail = obs.kind
        if obs.rating is not None:
            detail += " {}/5".format(obs.rating)
        if obs.note:
            detail += ': "{}"'.format(obs.note)
        lines.append("{}  {}".format(obs.timestamp.replace("T", " "), detail))
    return "\n".join(lines)


def format_report(report: AnalyticsReport) -> str:
    average = ("{:.2f} / 5".format(report.average_rating)
               if report.average_rating is not None else "n/a")
    lines = [
        "LIBRARY",
        "  Quotes:          {}".format(report.total_quotes),
        "  Favorites:       {}".format(report.favorites),
        "  Unique authors:  {}".format(report.unique_authors),
        "  Avg words/quote: {}".format(report.average_words),
        "",
        "ACTIVITY",
        "  Total views:     {}".format(report.total_views),
        "  Current streak:  {} day(s)".format(report.current_streak),
        "  Longest streak:  {} day(s)".format(report.longest_streak),
        "",
        "RATINGS",
        "  Rated quotes:    {}".format(report.rated_quotes),
        "  Average rating:  {}".format(average),
    ]
    for value in range(5, 0, -1):
        label = "{} star{}".format(value, "" if value == 1 else "s")
        lines.append("  {:<8}{}".format(
            label, report.rating_distribution.get(value, 0)))
    lines += ["", "TOP AUTHORS"]
    lines += ["  {} ({})".format(a, n) for a, n in report.top_authors] or [
        "  none"]
    lines += ["", "TOP TAGS"]
    lines += ["  {} ({})".format(t, n) for t, n in report.top_tags] or [
        "  none"]
    lines += ["", "MOST VIEWED"]
    lines += ["  {} ({} views)".format(truncate(t, 60), n)
              for t, n in report.most_viewed] or ["  none"]
    return "\n".join(lines)
