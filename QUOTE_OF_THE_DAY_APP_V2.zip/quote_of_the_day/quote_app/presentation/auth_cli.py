"""Account commands for the command line (presentation tier)."""
import getpass
import os
import sys
from typing import Callable, List, Optional, TextIO

from ..business.auth import AuthService

PasswordReader = Callable[[str], str]


def default_password_reader(prompt: str) -> str:
    """``QOTD_PASSWORD`` (for scripts) or a hidden interactive prompt."""
    env = os.environ.get("QOTD_PASSWORD")
    return env if env is not None else getpass.getpass(prompt)


def login(auth: AuthService, username: str,
          read_password: Optional[PasswordReader] = None) -> str:
    """Prompt for a password and authenticate; raises ``AuthError``."""
    reader = read_password or default_password_reader
    return auth.authenticate(username, reader("Password: "))


def register(auth: AuthService, args: List[str],
             read_password: Optional[PasswordReader] = None,
             out: Optional[TextIO] = None) -> int:
    """Handle ``register USERNAME``."""
    out = out or sys.stdout
    if len(args) != 1:
        print("Usage: python main.py register USERNAME", file=out)
        return 2
    reader = read_password or default_password_reader
    password = reader("New password: ")
    if os.environ.get("QOTD_PASSWORD") is None and read_password is None:
        if reader("Repeat password: ") != password:
            print("Error: passwords do not match", file=out)
            return 1
    name = auth.register(args[0], password)
    print("Account '{}' created. Use: python main.py --user {} <command>"
          .format(name, name), file=out)
    return 0
