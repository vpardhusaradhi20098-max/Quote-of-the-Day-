"""Tkinter GUI (presentation tier).

The GUI contains no business rules: it collects input, calls
``QuoteService`` and renders the result. Network calls run on a worker
thread and report back through a queue polled by the Tk event loop, so the
window never freezes.
"""
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Any, Callable, Optional

from .. import config
from ..business.auth import AuthService
from ..business.services import SORT_OPTIONS, QuoteService
from ..errors import QuoteAppError
from . import formatting

ORIGIN_LABELS = {
    "api": "Fetched online",
    "cached": "Saved earlier today",
    "offline": "Offline - built-in quote (check your connection)",
}


class QuoteApp(tk.Tk):
    """Main application window."""

    POLL_MS = 100

    def __init__(self, service: QuoteService,
                 username: Optional[str] = None) -> None:
        super().__init__()
        self.service = service
        self.current_id: Optional[str] = None
        self._results: "queue.Queue[tuple]" = queue.Queue()

        self.title(config.APP_NAME if not username else
                   "{} - {}".format(config.APP_NAME, username))
        self.geometry("960x640")
        self.minsize(800, 520)
        ttk.Style(self).theme_use("clam")

        self.status = tk.StringVar(value="Ready")
        self._build_ui()
        self.after(self.POLL_MS, self._poll)
        self.load_today()
        self.refresh_library()
        self.refresh_analytics()

    # ------------------------------------------------------------ layout
    def _build_ui(self) -> None:
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)
        self.tabs = notebook
        self._build_today_tab(notebook)
        self._build_library_tab(notebook)
        self._build_add_tab(notebook)
        self._build_analytics_tab(notebook)
        ttk.Label(self, textvariable=self.status, anchor="w",
                  relief="sunken").pack(fill="x", side="bottom")

    def _build_today_tab(self, notebook: ttk.Notebook) -> None:
        frame = ttk.Frame(notebook, padding=24)
        notebook.add(frame, text="Today")
        self.today_text = tk.StringVar()
        self.today_author = tk.StringVar()
        self.today_origin = tk.StringVar()
        self.today_meta = tk.StringVar()
        ttk.Label(frame, textvariable=self.today_text, wraplength=780,
                  font=("Georgia", 20, "italic"), justify="center"
                  ).pack(pady=(30, 10))
        ttk.Label(frame, textvariable=self.today_author,
                  font=("Georgia", 14)).pack()
        ttk.Label(frame, textvariable=self.today_origin,
                  foreground="#666").pack(pady=(4, 0))
        ttk.Label(frame, textvariable=self.today_meta).pack(pady=(4, 20))

        buttons = ttk.Frame(frame)
        buttons.pack()
        ttk.Button(buttons, text="Refresh today",
                   command=lambda: self.load_today(True)).grid(row=0, column=0,
                                                               padx=4)
        ttk.Button(buttons, text="Random quote",
                   command=self.load_random).grid(row=0, column=1, padx=4)
        ttk.Button(buttons, text="Toggle favorite",
                   command=self.toggle_favorite).grid(row=0, column=2, padx=4)

        actions = ttk.Frame(frame)
        actions.pack(pady=24)
        ttk.Label(actions, text="Rate:").grid(row=0, column=0)
        self.rating_box = ttk.Combobox(actions, values=[1, 2, 3, 4, 5],
                                       width=3, state="readonly")
        self.rating_box.current(4)
        self.rating_box.grid(row=0, column=1, padx=4)
        ttk.Button(actions, text="Save rating",
                   command=self.save_rating).grid(row=0, column=2, padx=4)
        ttk.Label(actions, text="Note:").grid(row=0, column=3, padx=(20, 0))
        self.note_entry = ttk.Entry(actions, width=34)
        self.note_entry.grid(row=0, column=4, padx=4)
        ttk.Button(actions, text="Save note",
                   command=self.save_note).grid(row=0, column=5, padx=4)

    def _build_library_tab(self, notebook: ttk.Notebook) -> None:
        frame = ttk.Frame(notebook, padding=8)
        notebook.add(frame, text="Library")

        bar = ttk.Frame(frame)
        bar.pack(fill="x")
        self.q_var = tk.StringVar()
        self.author_var = tk.StringVar()
        self.tag_var = tk.StringVar()
        self.fav_var = tk.BooleanVar(value=False)
        self.minrating_var = tk.StringVar(value="Any")
        self.sort_var = tk.StringVar(value="newest")
        fields = (("Search", self.q_var, 18), ("Author", self.author_var, 12),
                  ("Tag", self.tag_var, 10))
        for col, (label, var, width) in enumerate(fields):
            ttk.Label(bar, text=label).grid(row=0, column=col * 2)
            entry = ttk.Entry(bar, textvariable=var, width=width)
            entry.grid(row=0, column=col * 2 + 1, padx=(2, 8))
            entry.bind("<Return>", lambda _e: self.refresh_library())
        ttk.Checkbutton(bar, text="Favorites", variable=self.fav_var,
                        command=self.refresh_library).grid(row=0, column=6)
        ttk.Label(bar, text="Min rating").grid(row=1, column=0, pady=4)
        ttk.Combobox(bar, textvariable=self.minrating_var, width=5,
                     values=["Any", 1, 2, 3, 4, 5], state="readonly"
                     ).grid(row=1, column=1, sticky="w")
        ttk.Label(bar, text="Sort").grid(row=1, column=2)
        ttk.Combobox(bar, textvariable=self.sort_var, width=8,
                     values=list(SORT_OPTIONS), state="readonly"
                     ).grid(row=1, column=3, sticky="w")
        ttk.Button(bar, text="Search", command=self.refresh_library
                   ).grid(row=1, column=4, padx=4)
        ttk.Button(bar, text="Clear", command=self.clear_filters
                   ).grid(row=1, column=5)

        columns = ("quote", "author", "rating", "views", "fav")
        holder = ttk.Frame(frame)
        holder.pack(side="top", fill="both", expand=True, pady=6)
        self.tree = ttk.Treeview(holder, columns=columns, show="headings",
                                 selectmode="browse", height=10)
        for name, title, width in (("quote", "Quote", 420),
                                   ("author", "Author", 150),
                                   ("rating", "Rating", 70),
                                   ("views", "Views", 50),
                                   ("fav", "Fav", 40)):
            self.tree.heading(name, text=title)
            self.tree.column(name, width=width,
                             anchor="w" if name in ("quote", "author")
                             else "center")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self.show_detail())

        self.detail = tk.Text(frame, height=8, wrap="word", state="disabled")
        self.detail.pack(fill="x")

        row = ttk.Frame(frame)
        row.pack(fill="x", pady=(6, 0))
        for text, command in (("Toggle favorite", self.library_favorite),
                              ("Delete", self.delete_selected),
                              ("Export CSV", self.export_csv),
                              ("Import CSV", self.import_csv)):
            ttk.Button(row, text=text, command=command).pack(side="left",
                                                             padx=3)

    def _build_add_tab(self, notebook: ttk.Notebook) -> None:
        frame = ttk.Frame(notebook, padding=16)
        notebook.add(frame, text="Add quote")
        ttk.Label(frame, text="Quote text").pack(anchor="w")
        self.add_text = tk.Text(frame, height=6, wrap="word")
        self.add_text.pack(fill="x", pady=(0, 8))
        ttk.Label(frame, text="Author (optional)").pack(anchor="w")
        self.add_author = ttk.Entry(frame)
        self.add_author.pack(fill="x", pady=(0, 8))
        ttk.Label(frame, text="Tags (comma-separated, optional)"
                  ).pack(anchor="w")
        self.add_tags = ttk.Entry(frame)
        self.add_tags.pack(fill="x", pady=(0, 12))
        ttk.Button(frame, text="Save quote", command=self.add_quote
                   ).pack(anchor="w")

    def _build_analytics_tab(self, notebook: ttk.Notebook) -> None:
        frame = ttk.Frame(notebook, padding=8)
        notebook.add(frame, text="Analytics")
        top = ttk.Frame(frame)
        top.pack(fill="both", expand=True)
        self.report_text = tk.Text(top, width=52, wrap="word",
                                   state="disabled")
        self.report_text.pack(side="left", fill="y")
        right = ttk.Frame(top)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        ttk.Label(right, text="Ratings distribution").pack(anchor="w")
        self.chart = tk.Canvas(right, height=230, background="white",
                               highlightthickness=1)
        self.chart.pack(fill="x")
        ttk.Button(frame, text="Refresh", command=self.refresh_analytics
                   ).pack(anchor="w", pady=6)

    # ------------------------------------------------------- async helper
    def _run_async(self, work: Callable[[], Any],
                   on_done: Callable[[Any], None], message: str) -> None:
        self.status.set(message)

        def target() -> None:
            try:
                self._results.put((on_done, work(), None))
            except Exception as exc:  # reported to the UI thread
                self._results.put((on_done, None, exc))

        threading.Thread(target=target, daemon=True).start()

    def _poll(self) -> None:
        try:
            while True:
                callback, result, error = self._results.get_nowait()
                if error is not None:
                    self._show_error(error)
                else:
                    callback(result)
        except queue.Empty:
            pass
        self.after(self.POLL_MS, self._poll)

    def _show_error(self, error: Exception) -> None:
        self.status.set("Error: {}".format(error))
        if isinstance(error, QuoteAppError):
            messagebox.showerror(config.APP_NAME, str(error))
        else:
            messagebox.showerror(config.APP_NAME,
                                 "Unexpected error: {}".format(error))

    def _guard(self, action: Callable[[], Any]) -> Any:
        """Run a quick local action, showing friendly errors."""
        try:
            return action()
        except QuoteAppError as exc:
            self._show_error(exc)
            return None

    # -------------------------------------------------------- today tab
    def load_today(self, refresh: bool = False) -> None:
        self._run_async(lambda: self.service.get_quote_of_the_day(refresh),
                        self._show_daily, "Loading today's quote...")

    def load_random(self) -> None:
        self._run_async(self.service.fetch_random_quote, self._show_daily,
                        "Fetching a random quote...")

    def _show_daily(self, result) -> None:
        self.current_id = result.quote.id
        self._render_today(result.origin)
        self.status.set("Ready")
        self.refresh_library()
        self.refresh_analytics()

    def _render_today(self, origin: str = "") -> None:
        if not self.current_id:
            return
        view = self.service.get_quote(self.current_id)
        self.today_text.set('"{}"'.format(view.quote.text))
        self.today_author.set("- {}".format(view.quote.author))
        if origin:
            self.today_origin.set(ORIGIN_LABELS.get(origin, origin))
        self.today_meta.set("Rating: {}   Views: {}   {}".format(
            formatting.stars(view.rating), view.views,
            "Favorite" if view.quote.is_favorite else ""))

    def toggle_favorite(self) -> None:
        if self.current_id and self._guard(
                lambda: self.service.toggle_favorite(self.current_id)
        ) is not None:
            self._after_change()

    def save_rating(self) -> None:
        if self.current_id and self._guard(lambda: self.service.rate_quote(
                self.current_id, self.rating_box.get())) is not None:
            self.status.set("Rating saved")
            self._after_change()

    def save_note(self) -> None:
        if self.current_id and self._guard(lambda: self.service.add_note(
                self.current_id, self.note_entry.get())) is not None:
            self.note_entry.delete(0, "end")
            self.status.set("Note saved")
            self._after_change()

    def _after_change(self) -> None:
        self._render_today()
        self.refresh_library()
        self.refresh_analytics()

    # ------------------------------------------------------ library tab
    def clear_filters(self) -> None:
        self.q_var.set("")
        self.author_var.set("")
        self.tag_var.set("")
        self.fav_var.set(False)
        self.minrating_var.set("Any")
        self.sort_var.set("newest")
        self.refresh_library()

    def refresh_library(self) -> None:
        minimum = self.minrating_var.get()
        views = self._guard(lambda: self.service.search(
            self.q_var.get(), self.author_var.get(), self.tag_var.get(),
            self.fav_var.get(),
            None if minimum == "Any" else minimum, self.sort_var.get()))
        if views is None:
            return
        selected = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for view in views:
            self.tree.insert("", "end", iid=view.quote.id, values=(
                formatting.truncate(view.quote.text, 90), view.quote.author,
                formatting.stars(view.rating), view.views,
                "yes" if view.quote.is_favorite else ""))
        if selected and self.tree.exists(selected[0]):
            self.tree.selection_set(selected[0])
        self.status.set("{} quote(s) shown".format(len(views)))

    def _selected_id(self) -> Optional[str]:
        selection = self.tree.selection()
        return selection[0] if selection else None

    def show_detail(self) -> None:
        quote_id = self._selected_id()
        if not quote_id:
            return
        content = self._guard(lambda: "{}\n\nHistory:\n{}".format(
            formatting.format_quote(self.service.get_quote(quote_id)),
            formatting.format_history(self.service.history(quote_id))))
        if content is None:
            return
        self._set_text(self.detail, content)

    def library_favorite(self) -> None:
        quote_id = self._selected_id()
        if quote_id and self._guard(
                lambda: self.service.toggle_favorite(quote_id)) is not None:
            self._after_change()
            self.show_detail()

    def delete_selected(self) -> None:
        quote_id = self._selected_id()
        if not quote_id:
            messagebox.showinfo(config.APP_NAME, "Select a quote first.")
            return
        if not messagebox.askyesno(config.APP_NAME,
                                   "Delete this quote and its history?"):
            return
        if self._guard(lambda: self.service.delete_quote(quote_id) or True):
            if quote_id == self.current_id:
                self.current_id = None
                self.today_text.set("Quote deleted. Press 'Random quote'.")
                self.today_author.set("")
                self.today_meta.set("")
            self._set_text(self.detail, "")
            self.refresh_library()
            self.refresh_analytics()

    def export_csv(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV files", "*.csv")],
            initialfile="quotes.csv")
        if not path:
            return
        target = Path(path)
        activity = target.with_name(target.stem + "_activity.csv")

        def export() -> str:
            quotes = self.service.export_quotes_csv(target)
            events = self.service.export_observations_csv(activity)
            return "Exported {} quotes and {} activity records".format(
                quotes, events)
        self._run_async(export, self.status.set, "Exporting...")

    def import_csv(self) -> None:
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return

        def done(result) -> None:
            self.refresh_library()
            self.refresh_analytics()
            summary = "Imported {}, skipped {}.".format(result.added,
                                                         result.skipped)
            self.status.set(summary)
            if result.errors:
                summary += "\n\n" + "\n".join(result.errors[:8])
            messagebox.showinfo(config.APP_NAME, summary)
        self._run_async(lambda: self.service.import_quotes_csv(Path(path)),
                        done, "Importing...")

    # --------------------------------------------------------- add tab
    def add_quote(self) -> None:
        quote = self._guard(lambda: self.service.add_manual_quote(
            self.add_text.get("1.0", "end"), self.add_author.get(),
            self.add_tags.get()))
        if quote is None:
            return
        self.add_text.delete("1.0", "end")
        self.add_author.delete(0, "end")
        self.add_tags.delete(0, "end")
        self.status.set("Quote added")
        self.refresh_library()
        self.refresh_analytics()
        self.tabs.select(1)

    # ------------------------------------------------------ analytics
    def refresh_analytics(self) -> None:
        report = self._guard(self.service.analytics)
        if report is None:
            return
        self._set_text(self.report_text, formatting.format_report(report))
        self._draw_chart(report.rating_distribution)

    def _draw_chart(self, distribution: dict) -> None:
        canvas = self.chart
        canvas.delete("all")
        width = max(canvas.winfo_width(), 360)
        height = int(canvas["height"])
        peak = max(distribution.values()) or 1
        slot = (width - 40) / 5
        for index, stars in enumerate(range(1, 6)):
            count = distribution.get(stars, 0)
            bar = (height - 50) * count / peak
            x0 = 20 + index * slot + slot * 0.15
            x1 = 20 + (index + 1) * slot - slot * 0.15
            canvas.create_rectangle(x0, height - 30 - bar, x1, height - 30,
                                    fill="#4f7cac", outline="")
            canvas.create_text((x0 + x1) / 2, height - 30 - bar - 8,
                               text=str(count))
            canvas.create_text((x0 + x1) / 2, height - 14,
                               text="{} star{}".format(
                                   stars, "" if stars == 1 else "s"))

    @staticmethod
    def _set_text(widget: tk.Text, content: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", content)
        widget.configure(state="disabled")


def login_dialog(auth: AuthService, attempts: int = 3) -> Optional[str]:
    """Ask for credentials; returns the username or ``None`` if cancelled."""
    root = tk.Tk()
    root.withdraw()
    try:
        for _ in range(attempts):
            name = simpledialog.askstring(config.APP_NAME, "Username:",
                                          parent=root)
            if name is None:
                return None
            password = simpledialog.askstring(
                config.APP_NAME, "Password:", parent=root, show="*")
            if password is None:
                return None
            try:
                return auth.authenticate(name, password)
            except QuoteAppError as exc:
                messagebox.showerror(config.APP_NAME, str(exc), parent=root)
        return None
    finally:
        root.destroy()


def launch(service: QuoteService, username: Optional[str] = None) -> int:
    """Start the GUI; returns a process exit code."""
    try:
        app = QuoteApp(service, username)
    except tk.TclError as exc:
        print("Cannot open a window ({}). Use the CLI: "
              "python main.py --help".format(exc))
        return 1
    app.mainloop()
    return 0
