"""Command-line interface (presentation tier)."""
import argparse
import sys
from pathlib import Path
from typing import List, Optional, TextIO

from ..business.services import SORT_OPTIONS, QuoteService
from ..errors import QuoteAppError
from . import formatting


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="quote-of-the-day",
        description="Quote of the Day. Run without arguments for the GUI.")
    sub = parser.add_subparsers(dest="command", required=True)

    today = sub.add_parser("today", help="show today's quote")
    today.add_argument("--refresh", action="store_true",
                       help="ignore the cached quote and re-fetch")

    sub.add_parser("random", help="fetch a random quote")

    add = sub.add_parser("add", help="add your own quote")
    add.add_argument("text")
    add.add_argument("--author", default="")
    add.add_argument("--tags", default="", help="comma-separated")

    def add_filters(p: argparse.ArgumentParser) -> None:
        p.add_argument("--author", default="")
        p.add_argument("--tag", default="")
        p.add_argument("--favorites", action="store_true")
        p.add_argument("--min-rating", type=int, default=None)
        p.add_argument("--sort", choices=SORT_OPTIONS, default="newest")
        p.add_argument("--limit", type=int, default=0,
                       help="maximum results (0 = all)")

    search = sub.add_parser("search", help="search the library")
    search.add_argument("query", nargs="?", default="")
    add_filters(search)
    listing = sub.add_parser("list", help="list the library")
    add_filters(listing)

    for name, help_text in (("show", "show a quote and its history"),
                            ("favorite", "toggle favorite"),
                            ("delete", "delete a quote")):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("id")
        if name == "delete":
            p.add_argument("--yes", action="store_true",
                           help="confirm deletion")

    rate = sub.add_parser("rate", help="rate a quote 1-5")
    rate.add_argument("id")
    rate.add_argument("rating")

    note = sub.add_parser("note", help="attach a note to a quote")
    note.add_argument("id")
    note.add_argument("text")

    sub.add_parser("stats", help="show analytics")

    export = sub.add_parser("export", help="export to CSV")
    export.add_argument("quotes_path")
    export.add_argument("--observations", default="",
                        help="also export activity to this CSV file")

    imp = sub.add_parser("import", help="import quotes from CSV")
    imp.add_argument("path")
    return parser


def run(argv: List[str], service: QuoteService,
        out: Optional[TextIO] = None, err: Optional[TextIO] = None) -> int:
    """Execute one CLI command. Returns a process exit code."""
    out = out or sys.stdout
    err = err or sys.stderr
    args = build_parser().parse_args(argv)
    try:
        _dispatch(args, service, out)
    except QuoteAppError as exc:
        print("Error: {}".format(exc), file=err)
        return 1
    return 0


def _print_results(views, limit: int, out: TextIO) -> None:
    if limit and limit > 0:
        views = views[:limit]
    if not views:
        print("No quotes found.", file=out)
        return
    for view in views:
        print(formatting.format_quote(view), file=out)
        print(file=out)
    print("{} quote(s).".format(len(views)), file=out)


def _dispatch(args: argparse.Namespace, service: QuoteService,
              out: TextIO) -> None:
    command = args.command
    if command in ("today", "random"):
        result = (service.get_quote_of_the_day(args.refresh)
                  if command == "today" else service.fetch_random_quote())
        print(formatting.format_quote(service.get_quote(result.quote.id)),
              file=out)
        print("(source: {})".format(result.origin), file=out)
    elif command == "add":
        quote = service.add_manual_quote(args.text, args.author, args.tags)
        print("Added quote {}.".format(quote.id), file=out)
    elif command in ("search", "list"):
        views = service.search(
            getattr(args, "query", ""), args.author, args.tag,
            args.favorites, args.min_rating, args.sort)
        _print_results(views, args.limit, out)
    elif command == "show":
        print(formatting.format_quote(service.get_quote(args.id)), file=out)
        print("\nHistory:", file=out)
        print(formatting.format_history(service.history(args.id)), file=out)
    elif command == "favorite":
        state = service.toggle_favorite(args.id)
        print("Favorite: {}".format("on" if state else "off"), file=out)
    elif command == "rate":
        print("Rated {}/5.".format(service.rate_quote(args.id, args.rating)),
              file=out)
    elif command == "note":
        service.add_note(args.id, args.text)
        print("Note saved.", file=out)
    elif command == "delete":
        if not args.yes:
            raise QuoteAppError("Deletion needs confirmation: add --yes")
        service.delete_quote(args.id)
        print("Deleted.", file=out)
    elif command == "stats":
        print(formatting.format_report(service.analytics()), file=out)
    elif command == "export":
        count = service.export_quotes_csv(Path(args.quotes_path))
        print("Exported {} quote(s).".format(count), file=out)
        if args.observations:
            n = service.export_observations_csv(Path(args.observations))
            print("Exported {} activity record(s).".format(n), file=out)
    elif command == "import":
        result = service.import_quotes_csv(Path(args.path))
        print("Imported {}, skipped {}.".format(result.added, result.skipped),
              file=out)
        for line in result.errors[:10]:
            print("  " + line, file=out)
