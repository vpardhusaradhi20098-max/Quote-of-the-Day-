"""Central configuration. No secrets are needed; all APIs used are keyless.

The data directory can be overridden with the ``QOTD_DATA_DIR`` environment
variable, which is also how the automated tests isolate themselves.
"""
import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

APP_NAME = "Quote of the Day"
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Network behaviour
API_TIMEOUT_SECONDS = 8.0
API_RETRIES = 1
API_BACKOFF_SECONDS = 0.5
MAX_RESPONSE_BYTES = 1_000_000

# Input limits (enforced in business/validation.py)
MIN_QUOTE_LENGTH = 3
MAX_QUOTE_LENGTH = 1000
MAX_AUTHOR_LENGTH = 100
MAX_TAGS = 10
MAX_TAG_LENGTH = 30
MAX_NOTE_LENGTH = 500
MAX_QUERY_LENGTH = 200

# CSV import limits
MAX_CSV_BYTES = 5_000_000
MAX_CSV_ROWS = 10_000

DATA_FILE_NAME = "quotes.json"          # JSON backend
DB_FILE_NAME = "quotes.db"              # SQLite backend (default)
USERS_FILE_NAME = "users.json"
DEFAULT_STORAGE = "sqlite"              # override with QOTD_STORAGE=json

# Authentication (opt-in: only active once an account is registered)
PBKDF2_ITERATIONS = 200_000
MAX_FAILED_LOGINS = 5
LOCKOUT_MINUTES = 5
MIN_PASSWORD_LENGTH = 8
MAX_PASSWORD_LENGTH = 128
LOG_FILE_NAME = "app.log"


def data_dir() -> Path:
    """Return the directory used for the JSON store and log file."""
    override = os.environ.get("QOTD_DATA_DIR")
    return Path(override) if override else PROJECT_ROOT / "data"


def storage_backend() -> str:
    """Return the selected storage backend name (``sqlite`` or ``json``)."""
    return os.environ.get("QOTD_STORAGE", DEFAULT_STORAGE).strip().lower()


def user_data_dir(username: str) -> Path:
    """Each account gets its own isolated directory."""
    return data_dir() / "users" / username


def configure_logging(level: int = logging.INFO) -> None:
    """Send logs to a rotating file; never raises if the disk is read-only."""
    root = logging.getLogger()
    if any(getattr(h, "_qotd", False) for h in root.handlers):
        return
    root.setLevel(level)
    try:
        directory = data_dir()
        directory.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            directory / LOG_FILE_NAME, maxBytes=200_000, backupCount=2,
            encoding="utf-8")
    except OSError:
        handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"))
    handler._qotd = True  # marker so we only attach once
    root.addHandler(handler)
