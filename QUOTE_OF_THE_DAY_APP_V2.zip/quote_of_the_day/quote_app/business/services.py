"""Business-logic services (business tier).

``QuoteService`` is the only thing the presentation tier talks to. It
coordinates the API client and repository, enforces validation and owns the
rules for quote-of-the-day selection, search, ratings and CSV import/export.
"""
import logging
import random
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from ..data import csv_store
from ..data.api_client import QuoteApiClient
from ..data.fallback_quotes import FALLBACK_QUOTES
from ..data.repository_base import QuoteRepository
from ..errors import ApiError, NotFoundError, ValidationError
from ..models import (ObservationKind, Quote, QuoteObservation,
                      QuoteSource)
from . import validation
from .analytics import (AnalyticsReport, compute_analytics, latest_ratings,
                        view_counts)

LOG = logging.getLogger(__name__)

SORT_OPTIONS = ("newest", "oldest", "author", "rating", "views")

QUOTE_FIELDS = ["id", "text", "author", "tags", "source", "is_favorite",
                "created_at"]
OBSERVATION_FIELDS = ["obs_id", "parent_id", "timestamp", "kind", "rating",
                      "note"]


@dataclass
class QuoteView:
    """A quote together with derived data, ready for display."""
    quote: Quote
    rating: Optional[int]
    views: int


@dataclass
class DailyResult:
    """Result of fetching a quote: the quote and where it came from."""
    quote: Quote
    origin: str  # "cached", "api" or "offline"


@dataclass
class ImportResult:
    added: int = 0
    skipped: int = 0
    errors: List[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.errors is None:
            self.errors = []


class QuoteService:
    """Application use-cases."""

    def __init__(self, repository: QuoteRepository, api_client: QuoteApiClient,
                 clock: Callable[[], datetime] = datetime.now,
                 rng: Optional[random.Random] = None) -> None:
        self._repo = repository
        self._api = api_client
        self._clock = clock
        self._rng = rng or random.Random()

    # ------------------------------------------------------ quote of day
    def get_quote_of_the_day(self, force_refresh: bool = False
                             ) -> DailyResult:
        """Return today's quote, fetching it once per day.

        If the remote API fails, a deterministic built-in quote is used so
        the app always has something to show.
        """
        today = self._today()
        if not force_refresh:
            cached_id = self._repo.get_daily(today)
            cached = self._repo.get_quote(cached_id) if cached_id else None
            if cached is not None:
                self._record(cached.id, ObservationKind.VIEW)
                return DailyResult(cached, "cached")
        try:
            raw = self._api.fetch_today()
            quote, _ = self._store(raw.text, raw.author, [], QuoteSource.API)
            origin = "api"
        except (ApiError, ValidationError) as exc:
            LOG.warning("Using offline quote of the day: %s", exc)
            quote = self._offline_quote(
                index=self._clock().date().toordinal())
            origin = "offline"
        self._repo.set_daily(today, quote.id)
        self._record(quote.id, ObservationKind.VIEW)
        return DailyResult(quote, origin)

    def fetch_random_quote(self) -> DailyResult:
        """Fetch a random quote from the API (or offline list) and save it."""
        try:
            raw = self._api.fetch_random()
            quote, _ = self._store(raw.text, raw.author, [], QuoteSource.API)
            origin = "api"
        except (ApiError, ValidationError) as exc:
            LOG.warning("Using offline random quote: %s", exc)
            quote = self._offline_quote(
                index=self._rng.randrange(len(FALLBACK_QUOTES)))
            origin = "offline"
        self._record(quote.id, ObservationKind.VIEW)
        return DailyResult(quote, origin)

    def _offline_quote(self, index: int) -> Quote:
        text, author, tags = FALLBACK_QUOTES[index % len(FALLBACK_QUOTES)]
        quote, _ = self._store(text, author, tags, QuoteSource.OFFLINE)
        return quote

    # ------------------------------------------------------------ create
    def add_manual_quote(self, text: str, author: str = "",
                         tags: object = "") -> Quote:
        """Add a user-written quote; duplicates are rejected."""
        quote, created = self._store(text, author, tags, QuoteSource.MANUAL)
        if not created:
            raise ValidationError("That quote is already in your library")
        return quote

    def _store(self, text: object, author: object, tags: object,
               source: str) -> Tuple[Quote, bool]:
        clean_text = validation.validate_quote_text(text)
        clean_author = validation.validate_author(author)
        clean_tags = validation.parse_tags(tags)  # type: ignore[arg-type]
        quote = Quote.create(clean_text, clean_author, clean_tags, source,
                             self._clock())
        return self._repo.add_quote(quote)

    # ------------------------------------------------------------ read
    def get_quote(self, quote_id: str) -> QuoteView:
        quote = self._require(quote_id)
        observations = self._repo.observations()
        return QuoteView(quote, latest_ratings(observations).get(quote.id),
                         view_counts(observations).get(quote.id, 0))

    def search(self, query: Optional[str] = "", author: Optional[str] = "",
               tag: Optional[str] = "", favorites_only: bool = False,
               min_rating: Optional[int] = None, sort: str = "newest"
               ) -> List[QuoteView]:
        """Filter and sort the library.

        ``query`` is split into words and every word must appear in the
        quote text, author or tags (case-insensitive).
        """
        if sort not in SORT_OPTIONS:
            raise ValidationError(
                "Sort must be one of: {}".format(", ".join(SORT_OPTIONS)))
        words = validation.validate_query(query).lower().split()
        author_filter = validation.validate_query(author).lower()
        tag_filter = validation.validate_query(tag).lower()
        if min_rating is not None:
            min_rating = validation.validate_rating(min_rating)

        observations = self._repo.observations()
        ratings = latest_ratings(observations)
        views = view_counts(observations)

        results: List[QuoteView] = []
        for quote in self._repo.all_quotes():
            haystack = " ".join(
                [quote.text, quote.author] + quote.tags).lower()
            if not all(word in haystack for word in words):
                continue
            if author_filter and author_filter not in quote.author.lower():
                continue
            if tag_filter and tag_filter not in quote.tags:
                continue
            if favorites_only and not quote.is_favorite:
                continue
            rating = ratings.get(quote.id)
            if min_rating is not None and (rating or 0) < min_rating:
                continue
            results.append(QuoteView(quote, rating, views.get(quote.id, 0)))
        return self._sort(results, sort)

    @staticmethod
    def _sort(items: List[QuoteView], sort: str) -> List[QuoteView]:
        if sort == "newest":
            return sorted(items, key=lambda v: v.quote.created_at,
                          reverse=True)
        if sort == "oldest":
            return sorted(items, key=lambda v: v.quote.created_at)
        if sort == "author":
            return sorted(items, key=lambda v: (v.quote.author.lower(),
                                                v.quote.text.lower()))
        if sort == "rating":
            return sorted(items, key=lambda v: (-(v.rating or 0),
                                                v.quote.text.lower()))
        return sorted(items, key=lambda v: (-v.views, v.quote.text.lower()))

    def history(self, quote_id: str) -> List[QuoteObservation]:
        """Observations for one quote, newest first."""
        self._require(quote_id)
        # Index breaks timestamp ties so same-second events keep their order.
        indexed = sorted(enumerate(self._repo.observations(quote_id)),
                         key=lambda pair: (pair[1].timestamp, pair[0]),
                         reverse=True)
        return [obs for _, obs in indexed]

    # ------------------------------------------------------------ update
    def toggle_favorite(self, quote_id: str) -> bool:
        quote = self._require(quote_id)
        quote.is_favorite = not quote.is_favorite
        self._repo.update_quote(quote)
        self._record(quote_id, ObservationKind.FAVORITE
                     if quote.is_favorite else ObservationKind.UNFAVORITE)
        return quote.is_favorite

    def rate_quote(self, quote_id: str, rating: object) -> int:
        value = validation.validate_rating(rating)
        self._require(quote_id)
        self._record(quote_id, ObservationKind.RATING, rating=value)
        return value

    def add_note(self, quote_id: str, note: object) -> str:
        clean = validation.validate_note(note)
        self._require(quote_id)
        self._record(quote_id, ObservationKind.NOTE, note=clean)
        return clean

    def delete_quote(self, quote_id: str) -> None:
        if not self._repo.delete_quote(quote_id):
            raise NotFoundError("Quote {} not found".format(quote_id))

    # ------------------------------------------------------------ stats
    def analytics(self) -> AnalyticsReport:
        return compute_analytics(self._repo.all_quotes(),
                                 self._repo.observations(),
                                 today=self._clock().date())

    # --------------------------------------------------------- csv i/o
    def export_quotes_csv(self, path: Path) -> int:
        rows = [{**q.to_dict(), "tags": ";".join(q.tags)}
                for q in sorted(self._repo.all_quotes(),
                                key=lambda q: q.created_at)]
        return csv_store.write_rows(path, QUOTE_FIELDS, rows)

    def export_observations_csv(self, path: Path) -> int:
        rows = sorted(self._repo.observations(), key=lambda o: o.timestamp)
        return csv_store.write_rows(path, OBSERVATION_FIELDS,
                                    [o.to_dict() for o in rows])

    def import_quotes_csv(self, path: Path) -> ImportResult:
        """Import quotes; invalid rows are reported, never fatal."""
        result = ImportResult()
        for number, row in enumerate(csv_store.read_rows(path), start=2):
            try:
                quote, created = self._store(
                    row.get("text", ""), row.get("author", ""),
                    row.get("tags", ""), QuoteSource.IMPORT)
            except ValidationError as exc:
                result.skipped += 1
                result.errors.append("Row {}: {}".format(number, exc))
                continue
            if not created:
                result.skipped += 1
                continue
            result.added += 1
            if row.get("is_favorite", "").strip().lower() in (
                    "true", "1", "yes"):
                quote.is_favorite = True
                self._repo.update_quote(quote)
        return result

    # ----------------------------------------------------------- helpers
    def _today(self) -> str:
        return self._clock().date().isoformat()

    def _require(self, quote_id: str) -> Quote:
        quote = self._repo.get_quote(quote_id)
        if quote is None:
            raise NotFoundError("Quote {} not found".format(quote_id))
        return quote

    def _record(self, quote_id: str, kind: str, rating: Optional[int] = None,
                note: str = "") -> None:
        self._repo.add_observation(QuoteObservation.create(
            quote_id, kind, rating=rating, note=note, moment=self._clock()))
