"""Input validation and sanitisation (business tier).

Every value that enters the system - from the GUI, the CLI, a CSV file or the
remote API - passes through these functions before it is stored.
"""
import re
from typing import Iterable, List, Optional, Union

from .. import config
from ..errors import ValidationError

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
_TAG_PATTERN = re.compile(r"^[a-z0-9][a-z0-9 _-]*$")


def _clean(value: object) -> str:
    """Strip control characters and collapse runs of whitespace."""
    if not isinstance(value, str):
        raise ValidationError("Expected text")
    return " ".join(_CONTROL_CHARS.sub("", value).split())


def validate_quote_text(value: object) -> str:
    text = _clean(value)
    if len(text) < config.MIN_QUOTE_LENGTH:
        raise ValidationError(
            "Quote must be at least {} characters".format(
                config.MIN_QUOTE_LENGTH))
    if len(text) > config.MAX_QUOTE_LENGTH:
        raise ValidationError(
            "Quote must be at most {} characters".format(
                config.MAX_QUOTE_LENGTH))
    return text


def validate_author(value: object) -> str:
    """Blank authors become ``Unknown``."""
    author = _clean(value) if value is not None else ""
    if not author:
        return "Unknown"
    if len(author) > config.MAX_AUTHOR_LENGTH:
        raise ValidationError(
            "Author must be at most {} characters".format(
                config.MAX_AUTHOR_LENGTH))
    return author


def parse_tags(value: Union[str, Iterable[str], None]) -> List[str]:
    """Accept ``"a, b;c"`` or an iterable; return unique lowercase tags."""
    if value is None:
        return []
    if isinstance(value, str):
        pieces = re.split(r"[,;]", value)
    else:
        pieces = list(value)
    tags: List[str] = []
    for piece in pieces:
        tag = _clean(piece).lower()
        if not tag:
            continue
        if len(tag) > config.MAX_TAG_LENGTH:
            raise ValidationError(
                "Tag '{}' is longer than {} characters".format(
                    tag[:15], config.MAX_TAG_LENGTH))
        if not _TAG_PATTERN.match(tag):
            raise ValidationError(
                "Tag '{}' may only contain letters, digits, space, "
                "'-' and '_'".format(tag))
        if tag not in tags:
            tags.append(tag)
    if len(tags) > config.MAX_TAGS:
        raise ValidationError(
            "At most {} tags are allowed".format(config.MAX_TAGS))
    return tags


def validate_rating(value: object) -> int:
    """Ratings are whole numbers from 1 to 5."""
    if isinstance(value, bool) or (isinstance(value, float)
                                   and not value.is_integer()):
        raise ValidationError("Rating must be a whole number from 1 to 5")
    try:
        rating = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        raise ValidationError("Rating must be a number from 1 to 5") from None
    if not 1 <= rating <= 5:
        raise ValidationError("Rating must be between 1 and 5")
    return rating


def validate_note(value: object) -> str:
    note = _clean(value)
    if not note:
        raise ValidationError("Note cannot be empty")
    if len(note) > config.MAX_NOTE_LENGTH:
        raise ValidationError(
            "Note must be at most {} characters".format(
                config.MAX_NOTE_LENGTH))
    return note


def validate_query(value: Optional[str]) -> str:
    """Search text may be empty but is length-limited."""
    query = _clean(value) if value else ""
    if len(query) > config.MAX_QUERY_LENGTH:
        raise ValidationError(
            "Search text must be at most {} characters".format(
                config.MAX_QUERY_LENGTH))
    return query
