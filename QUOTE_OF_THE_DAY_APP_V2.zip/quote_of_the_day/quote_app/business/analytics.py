"""Pure analytics functions (business tier).

No I/O happens here: functions take records in and return a report, which
makes them trivial to test.
"""
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional, Tuple

from ..models import ObservationKind, Quote, QuoteObservation


@dataclass
class AnalyticsReport:
    total_quotes: int = 0
    favorites: int = 0
    unique_authors: int = 0
    total_views: int = 0
    rated_quotes: int = 0
    average_rating: Optional[float] = None
    average_words: float = 0.0
    current_streak: int = 0
    longest_streak: int = 0
    top_authors: List[Tuple[str, int]] = field(default_factory=list)
    top_tags: List[Tuple[str, int]] = field(default_factory=list)
    most_viewed: List[Tuple[str, int]] = field(default_factory=list)
    rating_distribution: Dict[int, int] = field(
        default_factory=lambda: {n: 0 for n in range(1, 6)})
    views_by_day: Dict[str, int] = field(default_factory=dict)
    sources: Dict[str, int] = field(default_factory=dict)


def latest_ratings(observations: Iterable[QuoteObservation]
                   ) -> Dict[str, int]:
    """Map quote id -> most recent rating."""
    ratings: Dict[str, Tuple[str, int]] = {}
    for obs in observations:
        if obs.kind == ObservationKind.RATING and obs.rating is not None:
            previous = ratings.get(obs.parent_id)
            if previous is None or obs.timestamp >= previous[0]:
                ratings[obs.parent_id] = (obs.timestamp, obs.rating)
    return {qid: value for qid, (_, value) in ratings.items()}


def view_counts(observations: Iterable[QuoteObservation]
                ) -> Dict[str, int]:
    """Map quote id -> number of recorded views."""
    return dict(Counter(o.parent_id for o in observations
                        if o.kind == ObservationKind.VIEW))


def compute_streaks(days: Iterable[date], today: date) -> Tuple[int, int]:
    """Return ``(current_streak, longest_streak)`` of consecutive days.

    The current streak is still alive if the latest active day is today or
    yesterday.
    """
    unique = sorted(set(days))
    if not unique:
        return 0, 0
    longest = run = 1
    for earlier, later in zip(unique, unique[1:]):
        run = run + 1 if later - earlier == timedelta(days=1) else 1
        longest = max(longest, run)
    last = unique[-1]
    if (today - last).days > 1:
        return 0, longest
    current = 1
    for earlier, later in zip(reversed(unique[:-1]), reversed(unique[1:])):
        if later - earlier == timedelta(days=1):
            current += 1
        else:
            break
    return current, longest


def compute_analytics(quotes: List[Quote],
                      observations: List[QuoteObservation],
                      today: Optional[date] = None,
                      top_n: int = 5) -> AnalyticsReport:
    """Aggregate library statistics."""
    today = today or date.today()
    report = AnalyticsReport()
    report.total_quotes = len(quotes)
    report.favorites = sum(1 for q in quotes if q.is_favorite)
    report.unique_authors = len({q.author.lower() for q in quotes})
    if quotes:
        report.average_words = round(
            sum(len(q.text.split()) for q in quotes) / len(quotes), 1)

    by_id = {q.id: q for q in quotes}
    views = view_counts(observations)
    report.total_views = sum(views.values())

    ratings = latest_ratings(observations)
    values = [r for qid, r in ratings.items() if qid in by_id]
    report.rated_quotes = len(values)
    if values:
        report.average_rating = round(sum(values) / len(values), 2)
        for value in values:
            report.rating_distribution[value] += 1

    report.top_authors = Counter(q.author for q in quotes).most_common(top_n)
    report.top_tags = Counter(
        tag for q in quotes for tag in q.tags).most_common(top_n)
    report.sources = dict(Counter(q.source for q in quotes))
    report.most_viewed = [
        (by_id[qid].text, count)
        for qid, count in sorted(views.items(),
                                 key=lambda kv: (-kv[1], kv[0]))
        if qid in by_id][:top_n]

    view_days = [datetime.fromisoformat(o.timestamp).date()
                 for o in observations if o.kind == ObservationKind.VIEW]
    report.views_by_day = dict(sorted(
        Counter(d.isoformat() for d in view_days).items()))
    report.current_streak, report.longest_streak = compute_streaks(
        view_days, today)
    return report
