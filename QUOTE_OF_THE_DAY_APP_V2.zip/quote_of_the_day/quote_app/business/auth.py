"""Authentication service (business tier).

* Passwords are hashed with salted PBKDF2-HMAC-SHA256 (200k iterations) and
  compared in constant time; plaintext is never stored or logged.
* After 5 consecutive failures an account is locked for 5 minutes.
* Failures use one generic message, so the app does not reveal whether a
  username exists.
* Authentication is opt-in: the app stays single-user until the first
  account is registered.
"""
import hashlib
import hmac
import logging
import re
import secrets
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional

from .. import config
from ..data.user_store import UserStore
from ..errors import AuthError, ValidationError

LOG = logging.getLogger(__name__)

_USERNAME = re.compile(r"^[a-z0-9][a-z0-9_.-]{2,29}$")
GENERIC_FAILURE = "Invalid username or password"


def validate_username(value: object) -> str:
    """Usernames are 3-30 chars of ``a-z 0-9 _ . -``; case-insensitive.

    The strict pattern also guarantees the name is a safe directory name.
    """
    if not isinstance(value, str):
        raise ValidationError("Username must be text")
    name = value.strip().lower()
    if not _USERNAME.match(name) or ".." in name:
        raise ValidationError(
            "Username must be 3-30 characters: letters, digits, '_', '.', "
            "'-' (starting with a letter or digit)")
    return name


def validate_password(password: object, username: str = "") -> str:
    if not isinstance(password, str):
        raise ValidationError("Password must be text")
    if not (config.MIN_PASSWORD_LENGTH <= len(password)
            <= config.MAX_PASSWORD_LENGTH):
        raise ValidationError(
            "Password must be {}-{} characters".format(
                config.MIN_PASSWORD_LENGTH, config.MAX_PASSWORD_LENGTH))
    if not (any(c.isalpha() for c in password)
            and any(c.isdigit() for c in password)):
        raise ValidationError(
            "Password must contain at least one letter and one digit")
    if username and username in password.lower():
        raise ValidationError("Password must not contain the username")
    return password


def _hash(password: str, salt: bytes, iterations: int) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt,
                               iterations).hex()


class AuthService:
    """Registers accounts and verifies credentials."""

    def __init__(self, store: UserStore,
                 clock: Callable[[], datetime] = datetime.now,
                 iterations: Optional[int] = None) -> None:
        self._store = store
        self._clock = clock
        self._iterations = iterations or config.PBKDF2_ITERATIONS

    def accounts_exist(self) -> bool:
        return self._store.has_users()

    def register(self, username: str, password: str) -> str:
        name = validate_username(username)
        validate_password(password, name)
        if self._store.get(name) is not None:
            raise ValidationError("That username is already taken")
        self._store.put(name, self._new_record(password))
        LOG.info("Account created: %s", name)
        return name

    def authenticate(self, username: str, password: str) -> str:
        """Return the canonical username or raise ``AuthError``."""
        try:
            name = validate_username(username)
        except ValidationError:
            self._burn_time(password)
            raise AuthError(GENERIC_FAILURE) from None
        record = self._store.get(name)
        if record is None:
            self._burn_time(password)
            raise AuthError(GENERIC_FAILURE)

        now = self._clock()
        locked_until = record.get("locked_until")
        if locked_until and datetime.fromisoformat(locked_until) > now:
            minutes = int((datetime.fromisoformat(locked_until) - now
                           ).total_seconds() // 60) + 1
            raise AuthError(
                "Too many failed attempts. Try again in {} minute(s)."
                .format(minutes))

        candidate = _hash(str(password), bytes.fromhex(record["salt"]),
                          int(record["iterations"]))
        if hmac.compare_digest(candidate, record["hash"]):
            record["failed_attempts"] = 0
            record["locked_until"] = None
            self._store.put(name, record)
            return name

        record["failed_attempts"] = int(record.get("failed_attempts", 0)) + 1
        if record["failed_attempts"] >= config.MAX_FAILED_LOGINS:
            record["locked_until"] = (
                now + timedelta(minutes=config.LOCKOUT_MINUTES)
            ).isoformat(timespec="seconds")
            record["failed_attempts"] = 0
            LOG.warning("Account locked after repeated failures: %s", name)
        self._store.put(name, record)
        raise AuthError(GENERIC_FAILURE)

    def change_password(self, username: str, old: str, new: str) -> None:
        name = self.authenticate(username, old)
        validate_password(new, name)
        record = self._new_record(new)
        self._store.put(name, record)

    # ----------------------------------------------------------- helpers
    def _new_record(self, password: str) -> Dict[str, Any]:
        salt = secrets.token_bytes(16)
        return {"salt": salt.hex(), "iterations": self._iterations,
                "hash": _hash(password, salt, self._iterations),
                "failed_attempts": 0, "locked_until": None,
                "created_at": self._clock().isoformat(timespec="seconds")}

    def _burn_time(self, password: object) -> None:
        """Do equivalent work for unknown users (timing uniformity)."""
        _hash(str(password), b"\x00" * 16, self._iterations)
