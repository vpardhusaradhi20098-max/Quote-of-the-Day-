"""Quote of the Day - a three-tier Python application.

Tiers:
    presentation/  Tkinter GUI and command-line interface
    business/      validation, services, analytics
    data/          JSON repository, CSV store, remote API client
"""
__version__ = "1.0.0"
